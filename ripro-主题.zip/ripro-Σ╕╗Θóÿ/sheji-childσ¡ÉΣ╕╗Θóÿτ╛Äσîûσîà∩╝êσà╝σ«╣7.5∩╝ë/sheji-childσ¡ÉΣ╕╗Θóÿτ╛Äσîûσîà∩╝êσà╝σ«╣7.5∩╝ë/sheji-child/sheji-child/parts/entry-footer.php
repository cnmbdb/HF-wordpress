<div class="entry-footer">
  <ul class="post-meta-box">

    <?php if (_cao('grid_is_time',true)) : ?>
    <li class="meta-date">
      <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo '<i class="fa fa-clock-o"></i> '._get_post_time();?></time>
    </li>
    <?php endif; ?>
    <?php get_original_tag()?>
    <?php if (is_site_shop_open()) : ?>
      <?php if ((_get_post_shop_status() || _get_post_shop_hide() || _get_post_video_status()) && _cao('grid_is_price',true)) : 
        $post_price = _get_post_price();
        $post_price =($post_price) ? $post_price : '免费' ;
      ?>
        <li class="meta-price"><span><?php echo '<i class="'._cao('site_money_icon').'"></i> '.$post_price;?></span></li>
      <?php endif; ?>
    <?php endif; ?>
    
  </ul>
</div>
<?php
/*
Template Name: vip介绍
*/
$home_mode_vip = _cao('home_vip_mod');
$sucaihu_vip_faq_data = _cao('sucaihu_vip_faq_data');
?>
<?php get_header(); ?>

<div class="newvip">
<div class="vip-top">
  <div class="hhviptop">
    <div class="wrapper"><i class="hhvipicon"></i>
      <h1><?php echo $home_mode_vip['title'];?></h1>
      <p class="descript">现在努力只为 不再仰望大神的后背！</p>
    </div>
  </div>
</div>
<div class="vip-container">
  <div class="vip-article-header">
    <h1 class="vip-article-title center">VIP</h1>
    <div class="vip-desc"> 您是本站第<em style="background:#fd6360; color:#fff; border-radius:15px; padding:2px 15px; margin:0px 10px;"><?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?></em>位注册会员 </div>
  </div>
  <div class="vip-wrapper">
    <div class="vip-content clearfix">
      <div class="vip-item item-1">
        <h6 style="background:<?php echo $home_mode_vip['_color'];?>">注册会员</h6>
        <span class="price">28<small><?php echo _cao('site_money_ua')?></small></span>
        <p class="border-decor"><span>永久</span></p>
        <?php echo $home_mode_vip['desc'];?>
        <?php if (is_user_logged_in()) : ?>
        <a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn btn-small signin-loader" style="background:<?php echo $item['_color'];?>"><i class="fa fa-unlink"></i> 立即升级</a>
        <?php else: ?>
        <a class="btn btn-small signin-loader login-btn btn-sm primary" style="background:<?php echo $home_mode_vip['_color'];?>"><i class="fa fa-user"></i> 登录购买</a>
        <?php endif; ?>
      </div>
      <?php foreach ( $home_mode_vip['vip_group'] as $item ) : ?>
      <div class="vip-item">
        <h6 style="background:<?php echo $item['_color'];?>"><?php echo $item['_time'];?></h6>
        <span class="price"><?php echo $item['_price'];?><small><?php echo _cao('site_money_ua')?></small></span>
        <p class="border-decor"><span><?php echo $item['_time'];?></span></p>
        <?php echo $item['_desc'];?>
        <?php if (is_user_logged_in()) : ?>
        <a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn btn-small signin-loader" style="background:<?php echo $item['_color'];?>"><i class="fa fa-unlink"></i> 立即升级</a>
        <?php else: ?>
        <a class="btn btn-small signin-loader login-btn btn-sm primary" style="background:<?php echo $item['_color'];?>"><i class="fa fa-user"></i> 登录购买</a>
        <?php endif; ?>
        
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  </div>
  <?php if (_cao('sucaihu_vip_faq')) : ?>
  <div class="vip-footer vip-wrapper">
    <h2>常见问题</h2>
    <p>FAQ</p>
    <div class="vip-faq box">
      <dl id="faq">
      

    <?php foreach ($sucaihu_vip_faq_data as $key => $item) {
      echo '<dt>'.$item['_title'].'</dt>';
      echo '<dd>'.$item['_answer'].'</dd>';
    } ?>

    </div>
  </div>
<script type="text/javascript">
$(document).ready(function() {
  $('#faq').find('dd').hide();
  //.隐藏显示的元素。
  $('#faq').find('dt').click(function() {
   var answer = $(this).next(); //当前节点的下一个节点
    // alert(answer.is(':visible')); 返回true / false
   if (answer.is(':visible')) {
//Boolean布尔值is( String expr )用一个表达式来检查当前选择的元素集合，
// 如果其中至少有一个元素符合这个给定的表达式就返回true。
//answer.is(':visible')是指可见的answer元素.
//如果可见就调用answer.slideUp();使之隐藏.
//else则是不可见的元素 调用answer.slideDown();使之显示.
//类似的写法还有answer.is(':first')answer.is(':last')之类的,类似于CSS的伪类a:hover
    answer.slideUp();
   } else {
    answer.slideDown();
   }
  });
});
</script>
<?php endif; ?>
<style type="text/css">
.site-content{ padding:0px;}
.term-bar,.lang{ display:none;}
</style>
<?php get_footer(); ?>

</div><!-- end sitecoent --> 

	<?php
	$mode_banner = _cao('mode_banner');
	$sucaihu_ui_autonomy_links = _cao('sucaihu_ui_autonomy_links');
	$sucaihu_ui_footer_wavecolor = _cao('sucaihu_ui_footer_wavecolor');
	?>

	
	<?php if (_cao( 'sucaihu_ui_footer_fav','true' ) ){
		get_template_part( 'parts/sucaihu-footer-fav' );
	}?>
	<footer class="site-footer">
    
            <div class="footer-navi">
		<div class="container">
			
			<?php if (_cao( 'is_diy_footer','true' ) ){
				get_template_part( 'parts/diy-footer' );
			}?>
            
            
			</div>
            
            
            
    </div>
            <div class="footer-bottom">
            <div class="container">
			<?php if (_cao('sucaihu_ui_footer_links')) : ?>
			<!--Friendship Links Start-->
			<div class="codesign-dw">
				<div class="col-xs-12 friend-links">
					<ul class="codesign-fl">
                        <li class="footer-logo">
                    <img class="tap-logo" src="<?php echo esc_url( _cao( 'site_footer_logo') ); ?>" data-dark="<?php echo esc_url(_cao( 'site_footer_logo')); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                </li>
						<?php wp_list_bookmarks('title_li=&show_images=0&categorize=0'); ?>
						<?php if (_cao('sucaihu_ui_autonomy_link')) : ?>
						<li>
                        <a class="ctrl-apply" href="<?php echo $title = ($sucaihu_ui_autonomy_links['_url']); ?>">申请友链+</a>
                    	</li>
                    	<?php endif; ?>
					</ul>
				</div>
			</div>
			<!--Friendship Links End-->
			<?php endif; ?>
			
			<?php if ( _cao( 'cao_copyright_text', '' ) != '' ) : ?>
			  <div class="site-info" style="overflow:hidden">
              <div style="float:left;">
			    <?php echo _cao( 'cao_copyright_text', '' ); ?>
			    <?php if(_cao('cao_ipc_info')) : ?>
			    <a href="http://www.beian.miit.gov.cn" target="_blank" class="text"><?php echo _cao('cao_ipc_info')?><br></a>
			    <?php endif; ?>
			  </div>
              <div style="float:right;">查询<?php echo get_num_queries();?>次，耗时<?php echo timer_stop(0,5);?></div>
              </div>
              
			<?php endif; ?>
		</div>
        </div>
	</footer>
	
	<?php if (_cao( 'sucaihu_ui_footer_float','true' ) ){
		get_template_part( 'parts/sucaihu-float' );
	}?>
	
<?php if (_cao('pro_ui_footer_float')) : ?>
<div class="rollbar">
	<?php if (_cao('site_kefu_qq')) : ?>
    <div class="rollbar-item tap-qq" etap="tap-qq"><a target="_blank" title="QQ咨询" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _cao('site_kefu_qq');?>&site=qq&menu=yes"><i class="fa fa-qq"></i></a></div>
    <?php endif; ?>

	<div class="rollbar-item" etap="to_full" title="全屏页面"><i class="fa fa-arrows-alt"></i></div>
	<?php if (_cao('is_lxh5068.com_dark_btn')) : ?>
    <div class="rollbar-item tap-dark" etap="tap-dark" title="切换模式"><i class="mdi mdi-brightness-4"></i></div>
    <?php endif; ?>
	<div class="rollbar-item" etap="to_top" title="返回顶部"><i class="fa fa-angle-up"></i></div>
</div>
<?php endif; ?>

<div class="dimmer"></div>
<script>
$('.cat-nav li').click(function() {
	$(this).addClass('active').siblings().removeClass('active');
})
</script>

<script type="text/javascript">
	jQuery(document).ready(function($){
		$('.ct h3 span').click(function(){
		$(this).addClass("selected").siblings().removeClass();
		$('.ct > ul').eq($(this).index()).addClass('show');
		$('.ct > ul').eq($(this).index()).siblings().removeClass('show');
		});
		$("pre > code").addClass("language-php");
	});
	jQuery(".header-dropdown").hover(function() {
		jQuery(this).addClass('active');
	}, function() {
		jQuery(this).removeClass('active');
	});
	$('.h-screen li').click(function(){
	$(this).addClass("on").siblings().removeClass();
	$('.ct > ul').eq($(this).index()).addClass('show');
	$('.ct > ul').eq($(this).index()).siblings().removeClass('show');
	});
	$(".h-soup li i").click(function(){
		var soupBtn = $(this).parent();
		$(".h-soup li").removeClass("open");
		soupBtn.addClass("open");
	});
	$('.srctive').countUp({
		delay: 10,
		time: 500
	});
</script>

<script> 
	var ndt = $("#help dt");
	var ndd = $("#help dd");
	ndd.eq(0).show();
	ndt.click(function () {
    ndd.hide();
    $(this).next().show();
	});
	var AnimationPlay = false;
var LayerDisplay = true;
var Win_scrollTop = jQuery(window).scrollTop();
jQuery(window).scroll(function() {
    if (AnimationPlay) {
        return;
    }

    var Win_scrollTop2 = jQuery(window).scrollTop();
    if (Win_scrollTop2 > Win_scrollTop) {
        if (LayerDisplay) {
            LayerDisplay = false;
            AnimationPlay = true;

            jQuery('.wic_slogin').stop().animate({
                'bottom': '-130px',
                'opacity': '0',
                'visibility': 'hidden'
            }, 500, function() {
                AnimationPlay = false;
            });
        }

    } else if (Win_scrollTop2 <= Win_scrollTop) {
        if (!LayerDisplay) {
            LayerDisplay = true;
            AnimationPlay = true;

            jQuery('.wic_slogin').stop().animate({
                'bottom': '0px',
                'opacity': '1',
                'visibility': 'visible'
            }, 300, function() {
                AnimationPlay = false;
            });
        }
    }
    Win_scrollTop = Win_scrollTop2;
});
</script>

<?php if (!is_user_logged_in() && is_site_shop_open()) : ?>
    <?php get_template_part( 'parts/popup-signup' ); ?>
<?php endif; ?>

<?php get_template_part( 'parts/off-canvas' ); ?>

<?php if (_cao('is_console_footer','true')) : ?>
<script>
    console.log("\n %c <?php echo _the_theme_name().' V'._the_theme_version();?> %c https://vip.lxh5068.com \n\n", "color: #fadfa3; background: #030307; padding:5px 0;", "background: #fadfa3; padding:5px 0;");
    console.log("SQL 请求数：<?php echo get_num_queries();?>");
    console.log("页面生成耗时： <?php echo timer_stop(0,5);?>");
</script>

<?php endif; ?>

<?php if (_cao('web_js')) : ?>
<?php echo _cao('web_js');?>
<?php endif; ?>
<?php if (_cao('cao_disabled_f12')) : ?>
<script type="text/javascript">
((function() {
    var callbacks = [],
        timeLimit = 50,
        open = false;
    setInterval(loop, 1);
    return {
        addListener: function(fn) {
            callbacks.push(fn);
        },
        cancleListenr: function(fn) {
            callbacks = callbacks.filter(function(v) {
                return v !== fn;
            });
        }
    }
    function loop() {
        var startTime = new Date();
        debugger;
        if (new Date() - startTime > timeLimit) {
            if (!open) {
                callbacks.forEach(function(fn) {
                    fn.call(null);
                });
            }
            open = true;
            window.stop();
            alert('不要扒我了');
            window.location.reload();
        } else {
            open = false;
        }
    }
})()).addListener(function() {
    window.location.reload();
});
</script>
<?php endif; ?>

<?php wp_footer(); ?>

</body>
</html>
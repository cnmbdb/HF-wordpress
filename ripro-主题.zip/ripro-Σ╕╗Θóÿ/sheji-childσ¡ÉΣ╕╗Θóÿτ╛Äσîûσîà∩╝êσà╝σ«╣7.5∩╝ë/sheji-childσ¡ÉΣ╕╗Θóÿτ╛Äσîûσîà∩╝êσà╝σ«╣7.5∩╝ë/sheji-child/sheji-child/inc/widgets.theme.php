
<?php if (!defined('ABSPATH')) 
{
	die;
}
CSF::createWidget('cao_widget_qqq', array( 'title' => 'RIPRO-QQ群', 'classname' => 'widget-qqq', 'description' => '加群小工具', 'fields' => array( array( 'id' => 'title', 'type' => 'text', 'title' => '标题', 'default' => '站长交流群', ), array( 'id' => '_zhumiaoshu', 'type' => 'text', 'title' => '主描述', 'default' => '互联网站长技术交流群', ), array( 'id' => '_fumiaoshu', 'type' => 'text', 'title' => '副描述', 'default' => '共同学习，共同进步，共同成长！', ), array( 'id' => '_lianjie', 'type' => 'text', 'title' => '链接地址', 'default' => 'https://shang.qq.com/wpa/qunwpa?idkey=10086', ), ), ));
if (!function_exists('cao_widget_qqq')) 
{
	function cao_widget_qqq($args, $instance) 
	{
		echo $args['before_widget'];
		if ( ! empty( $instance['title'] ) ) 
		{
			echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
		}
		$_zhumiaoshu = $instance['_zhumiaoshu'];
		$_fumiaoshu = $instance['_fumiaoshu'];
		$_lianjie = $instance['_lianjie'];
		echo '<section class="sucaihu-jiaqun">';
		echo '<div class="sucaihu-jiaqun-small">';
		echo '<p>'.$_zhumiaoshu.'<br> '.$_fumiaoshu.'</p>';
		echo '<a href="'.$_lianjie.'" class="btn sucaihu-jiaqun-btn-on" uk-toggle=""><i class="fa fa-qq"></i>QQ交流群</a>';
		echo '<div class="helper-thumb"><img src="/wp-content/themes/sheji-child/assets/images/qunbg.png"> </div>';
		echo '</div>';
		echo '</section>';
		echo $args['after_widget'];
	}
}
?>
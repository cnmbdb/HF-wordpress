<?php 
global $current_user;
?>

<?php $bgurl = _cao('site-head-bgimg'); ?>

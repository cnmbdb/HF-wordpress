<div class="cao_entry_header">
<?php cao_entry_header([
    'tag'      => 'h1',
    'link'     => false,
    'category' => true,
    'date'     => true,
    'author'   => true,
    'edit'   => true,
]);?>
</div>
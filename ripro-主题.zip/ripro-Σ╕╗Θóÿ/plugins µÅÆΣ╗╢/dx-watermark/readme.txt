﻿=== Plugin Name ===
Contributors: daxiawp
Donate link: http://www.jumawu.com
Tags: watermark, images, pictures, Post, text watermark, upload, image watermark, image
Requires at least: 3.1
Tested up to: 3.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.jumawu.com/licenses/gpl-2.0.html

The pictures automatically add watermark. 图片自动添加水印.


== Description ==

Automatically add a picture watermark, can select text or pictures are two types. 自动给图片添加水印，可选择文本或图片两种类型。
详情：[http://www.jumawu.com/dx-watermark.html](http://www.jumawu.com/dx-watermark.html)

== Installation ==

可以通过以下两种方法的其中一种来安装DX-Watermark插件：

1. 将下载的文件解压缩，然后将`dx-watermark`文件夹 上传到 `/wp-content/plugins/`目录，在插件后台启用

2. 直接在后台-安装插件，搜索'dx-watermark'，按照提示安装启用

== Frequently Asked Questions ==


== Screenshots ==

1. 后台截图1
2. 后台截图2

== Changelog ==

= 1.0.4 =
* Fix some php version does not display a preview of the bug. 修复一些php版本无法显示预览的bug

= 1.0.3 =
* Customize jpeg quality. 自定义jpeg图片水印质量

= 1.0.2 =
* Repair bug. 修复bug

= 1.0.1 =
* Repair jpg images to add watermarks too large bug. 修复jpg图片添加水印后过大的bug

= 1.0.0 =
* publish DX-Watermark plugin. 发布DX-Watermark插件


== Upgrade notice ==



== Arbitrary section 1 ==

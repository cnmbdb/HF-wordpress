=== WPCopyRights网站防复制插件 ===
Contributors: laobuluo
Donate link: https://www.jumawu.com/donate/
Tags:版权插件,防止复制
Requires at least: 4.5.0
Tested up to: 5.7.1
Stable tag: 5.1
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.jumawu.com/licenses/gpl-2.0.html

WordPress网站防复制插件，涵盖禁止右键、F12、复制、黏贴，可设置放行页面和文章。

== Description ==

WPCopyRights WordPress防止复制版权插件，可以设置禁止右键、选择文本、F12、设置允许页面和文章权限。

## 插件特点

1. 允许常规鼠标选择、复制、黏贴、打印、另存为的禁止使用。
2. 可以设置管理员、登录用户不限制
3. 可放心特定页面、文章不限制

插件更多详细介绍和安装：[https://www.jumawu.com/wpcopyrights.html](https://www.jumawu.com/wpcopyrights.html)

## 开发网站

* [老部落](https://www.jumawu.com/ "老部落")

* [老蒋部落](https://www.itbulu.com/ "老蒋部落")

欢迎加入公众号：老蒋玩运营（公众号）

== Installation ==

* 把插件文件夹上传到/wp-content/plugins/目录下<br />
* 在后台插件列表中激活<br />
* 在 工具- WPCopyRights设置 菜单中勾选需要设置开启。<br />


== Frequently Asked Questions ==

* 1.当发现插件出错时，开启调试获取错误信息。
* 2.根据个人喜好自行开启。

== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png

== Frequently Asked Questions ==

= 如何使用插件 =

下载激活且在【工具】找到插件设置，然后开启插件且设置需要的功能。

= 开启插件之后无法注册用户 =

如果有用户注册功能或者输入文本的，不能禁止左键

== Changelog ==

= 5.1 =

* 细节修改和文档BUG

= 4.4 =

* 兼容最新版本WP5.7.1测试

= 4.3 =

* 兼容最新版本WP5.6测试

= 4.2 =

* 兼容最新版本WP测试
* 修改禁止拖动图片兼容问题

= 4.1 =

* 重构插件前端
* 修改禁止拖动图片兼容问题

= 3.1 =

* 解决移动端锁定问题
* 解决文本框无法写入问题

= 2.2 =

* 兼容WP5.4.2测试
* 解决限制太严格问题


= 2.1 =

* 解决禁止选择文本后无法搜索问题
* 解决禁止F12后无法输入文本问题

= 1.3 =

* 优化部分细节
* 完善文档说明


= 1.2 =

* 解决在移动端禁止F12开启导致空白页问题

= 1.1 =

* 最新版本WordPress5.4.1测试通过

= 0.1 =

* 上线常规功能
* 放行管理员和登录用户权限

== Upgrade Notice ==
* 
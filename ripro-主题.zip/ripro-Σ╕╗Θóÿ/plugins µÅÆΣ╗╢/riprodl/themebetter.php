<?php if (!_get_post_shop_status() || _get_post_shop_hide()) { ?>
           <?php
	$sidebar = cao_sidebar();
	$column_classes = cao_column_classes( $sidebar );
		get_header();
?>
      <?php } else { ?>


<?php
	$sidebar = cao_sidebar();
	$column_classes = cao_column_classes( $sidebar );
        global $post;
        $post_id = $post->ID;
        $user_id = is_user_logged_in() ? wp_get_current_user()->ID : 0;
        // 判断是否资源文章 cao_status
        if (!_get_post_shop_status() || _get_post_shop_hide()) {
            return false;
        }
       
        // if (!$instance['is_absrate']) {
        //   echo '<div class="rateinfo-abs"></div>';
        // }
        // 内容区域
        $cao_price       = get_post_meta($post_id, 'cao_price', true);
        $cao_vip_rate    = get_post_meta($post_id, 'cao_vip_rate', true);
        $cao_downurl     = get_post_meta($post_id, 'cao_downurl', true);
        $cao_pwd         = get_post_meta($post_id, 'cao_pwd', true);
        $cao_demourl     = get_post_meta($post_id, 'cao_demourl', true);
        $cao_paynum      = get_post_meta($post_id, 'cao_paynum', true);
        $cao_info        = get_post_meta($post_id, 'cao_info', true);
        $cao_ver         = get_post_meta($post_id, 'cao_ver', true);
        $cao_is_boosvip  = get_post_meta($post_id, 'cao_is_boosvip', true);
        $cao_qqhao  = get_post_meta($post_id, 'ac_qqhao', true);
        
        $cao_close_novip_pay  = get_post_meta($post_id, 'cao_close_novip_pay', true);
       
        $site_vip_name=_cao('site_vip_name');
        $site_money_ua=_cao('site_money_ua');
          $site_no_vip_name=_cao('site_no_vip_name');
        // 优惠信息
        
 
        
        switch ($cao_vip_rate) {
            case 1:
                $rate_text = '暂无优惠';
                break;
            case 0:
                $rate_text = $site_vip_name . '免费';
                break;
            default:
                $rate_text = $site_vip_name . ' ' . ($cao_vip_rate * 10) . ' 折';
        }
        
        
        //VIP优惠腰椎间盘突出 如果有优惠显示折扣信息 style=" text-decoration: line-through; "
        $CaoUser = new CaoUser($user_id);
        $PostPay = new PostPay($user_id, $post_id);
        $cao_this_am   = $cao_price . $site_money_ua;
        $pric_style = '';
         $min_price = ($cao_price * $cao_vip_rate==0 || $cao_is_boosvip) ? 0 : $cao_price * $cao_vip_rate ;
	get_header();
?>
<?php } ?>

    
<div class="container">
	<div class="breadcrumbs">
	<?php echo dimox_breadcrumbs(); ?>
	</div>
		<?php if (!_get_post_shop_status() || _get_post_shop_hide()) { ?>
    
      <?php } else { ?>
      
   <link rel='stylesheet' id='dashicons-css'  href='<?php bloginfo('url'); ?>/wp-includes/css/dashicons.min.css?ver=5.1.1' type='text/css' media='all' />   

   <div class="theme-item-focus" id="info">


<div class="container">
        
        

        <div class="theme-item-sidebar">
            <div class="theme-item-image" >
                <span>
                    <img alt="<?php echo get_the_title(); ?>" class="themeimg" src="<?php echo esc_url(_get_post_timthumb_src()); ?>">
                         <?php if ($cao_demourl) { ?>

     <a class="btn btn-primary-outline theme-item-preview" target="_blank" href="<?php echo $cao_demourl; ?>"><i class="iconfont"></i> 预览演示站</a>
            <?php }else{ ?>
          <span class="btn btn-primary-outline theme-item-preview" target="_blank" href="#"><i class="iconfont">&#xe608;</i> 暂无演示</span>
            <?php }; ?>
        
                   
                </span>
            </div>
            <?php if ( c7v5_get_option( 'dl_ercode' ) ){ ?>
            <span class="theme-demo-qrcode"><img src="<?php echo get_template_directory_uri(); ?>/inc/plugins/qrcode.php?data=<?php the_permalink(); ?>" alt="<?php the_title(); ?>"/><small>手机扫码预览</small>
            
           
            </span>
            
            <?php } ?>
        </div>

        <div class="theme-item-fcontent">

            
            <h1><?php echo get_the_title(); ?></h1>
        <?php if ($cao_price * $cao_vip_rate==0) {
                $vip_price_rate_str='免费'; 
                $vipicon='fa-circle-o';
            }else{
                $vip_price_rate_str='<dfn>¥</dfn> ' . ($cao_price * $cao_vip_rate) . ' <dfn>' . $site_money_ua . '</dfn>';
                $vipicon='fa-times-circle-o';
            } ; ?>

            <div class="theme-item-price">
            	<div class="yuan_price">
            			<?php if ($CaoUser->vip_status()) { ?>
                                	<h5><?php echo $site_vip_name; ?> :</h5>    
            			<?php } else { ?>
            				<h5>售价：</h5> 
            			<?php }; ?>   
                                    <?php if (is_site_shop_open()) : ?>
                                    
                         		
     <?php if ($CaoUser->vip_status()) {
                $cao_this_am   = ($cao_price * $cao_vip_rate) . $site_money_ua;
                $pric_style = 'style="text-decoration: line-through;"';
               
                echo '<b><strong>' . $vip_price_rate_str . '</strong></b>';
            	
            }else if ($cao_close_novip_pay && !$CaoUser->vip_status()){
  
          echo '<span class="boosvip-abs"><i class="fa fa-info-circle"></i> 暂无购买权限';
            }else{
               	if ($cao_price==0) {
   
            $cao_price_str = '<strong><font '.$pric_style.'><dfn>¥</dfn> 免费</font></strong>' ;
              echo $cao_price_str; 
            
                }else{
        
            $cao_price_str = ' <strong><font '.$pric_style.'><dfn>¥</dfn>' . $cao_price . '</font> <dfn>'. $site_money_ua . '</dfn></strong>' ;
              echo $cao_price_str; 
                 }
   
            }; ?>                 
                                    
    <?php endif; ?>
 
            	</div>

                
                                   
       <ul class="pricing-options">
       	 
       	  <?php if ($cao_close_novip_pay) { 
                echo '<li><i class="fa fa-times-circle-o"></i> 普通用户暂无购买权限  <a class="label label-warning pricing__opt" href="/user?action=vip" class="pay-vip">升级'.$site_vip_name.'</a></li>';
            }else{
                echo '<li><i class="fa fa-circle-o"></i> '.$site_no_vip_name.'用户购买价格 : <span class="pricing__opt">' . $cao_price .''. $site_money_ua. '</span></li>';
            } ?>
    
       <?php if ($min_price < $cao_price || $cao_close_novip_pay) {
                if ($CaoUser->vip_status()) {
                    echo '<li style="color: #21b3fc;"><i class="fa fa-check-circle"></i> '.$site_vip_name.'会员购买价格 : <span class="type_icont_2"><i class="fa fa-diamond"></i>' . ($cao_price * $cao_vip_rate) . $site_money_ua. '</span></li>';
                }else{
                    echo '<li><i class="fa fa-circle-o"></i> '.$site_vip_name.'会员购买价格 :<span class="pricing__opt type_icont_2"><i class="fa fa-diamond"></i>' . ($cao_price * $cao_vip_rate) . $site_money_ua. '</span></li>';
                }
            } ?>
    
    <?php if ($cao_is_boosvip) {
                if (is_boosvip_status($user_id)) {
                    echo '<li style="color: #FF9800;" ><i class="fa fa-check-circle"></i> 终身'.$site_vip_name.'购买价格 : <span class="pricing__opt type_icont_2">免费</span></li>';
                }else{
                    echo '<li ><i class="fa fa-circle-o"></i> 终身'.$site_vip_name.'购买价格 : <span class="pricing__opt type_icont_2 ">免费</span></li>';
                }
            } ?>
    
       	
       	</ul>
                    
                            </div>
            
            <div class="theme-item-orderarea">
  
      <?php   $create_nonce = wp_create_nonce('caopay-' . $post_id);
    
        
        $jumawu_comPayAuth = new jumawu.comPayAuth($user_id,$post_id);
         $cao_pwd_html = (empty($cao_pwd)) ? '' : '<span class="pwd"><span title="点击一键复制密码" id="refurl" class="copypaw copypaw btn btn-demo" data-clipboard-text="'.$cao_pwd.'">'.$cao_pwd.'</span></span>' ;
        switch ($jumawu_comPayAuth->ThePayAuthStatus()) {
          case 11: //免登陆  已经购买过 输出OK
            echo cao_get_post_downBtn($post_id); // 输出下载按钮
          echo $cao_pwd_html;
            break;
          case 12: //免登陆  登录后查看
           
              if (!_cao('is_jumawu.com_free_no_login')) {
                echo '<a class="login-btn btn btn-primary"><i class="fa fa-user"></i> 登录后下载</a>';
            }else{
                echo cao_get_post_downBtn($post_id); // 输出下载按钮
                echo $cao_pwd_html;
            }
            break;
          case 13: //免登陆 输出购买按钮信息
            if ($cao_close_novip_pay && !$CaoUser->vip_status()) {
                echo '<button type="button" class="btn btn--primary disabled" >暂无购买权限</button>';
                echo '<a target="_blank" href="'.esc_url(home_url('/user?action=vip')).'" class="login-btn btn btn--danger btn--block mt-10">购买授权</a>';
            }else{
                echo '<button type="button" class="btn btn-primary down click-pay" data-postid="' . $post_id . '" data-nonce="' . $create_nonce . '" data-price="' . $cao_this_am . '">支付下载</button>';
            }
            break;
          case 21: //登陆后  已经购买过 输出OK
            echo cao_get_post_downBtn($post_id); // 输出下载按钮
            if ($cao_pwd) {
                echo '<span class="pwd"><span title="点击一键复制密码" id="refurl" class="copypaw copypaw btn btn-demo" data-clipboard-text="'.$cao_pwd.'">'.$cao_pwd.'</span></span>';
            }
            break;
          case 22: //登陆后  输出购买按钮信息
            if ($cao_close_novip_pay && !$CaoUser->vip_status()) {
                echo '<button type="button" class="btn btn--primary disabled" >暂无购买权限</button>';
                  echo '<a target="_blank" href="'.esc_url(home_url('/user?action=vip')).'" class="btn btn--danger btn--block mt-10">购买授权</a>';
            }else{
                echo '<button type="button" class="click-pay login-btn btn btn-primary" data-postid="' . $post_id . '" data-nonce="' . $create_nonce . '" data-price="' . $cao_this_am . '">立即购买</button>';
            }
            break;
          case 31: //没有开启免登录 没有登录 输出登录后进行操作
            echo '<a class="login-btn btn btn-primary"><i class="fa fa-user"></i> 登录后购买</a>';
            break;
        }
 ; ?>
                
    <a target="_blank" class="btn btn-demo" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo _cao('site_kefu_qq') ;?>&site=qq&menu=yes"><i class="fa fa-qq"></i> 联系客服</a>  
           
            </div>
             
      <div class="theme-item-sv">
               
                <ul>
                    <li><i class="iconfont"></i><span>免费售前咨询</span></li>
                    <li><i class="iconfont"></i><span>免费安装指导</span></li>
                    <li><i class="iconfont">  </i><span>付费安装资源</span></li>
                    <li><i class="iconfont"></i><span>付费终身升级</span></li>
                    <li><i class="iconfont"></i><span>QQ保障售后服务</span></li>
                    <li><i class="iconfont"></i><span>网站应急咨询顾问</span></li>
                </ul>
            </div>

        </div>

        <div class="theme-item-brand">
            
            <div class="theme-item-brand1"><a href="/user?action=vip">
                <i class="iconfont" aria-hidden="true"></i></a>
                <p>联系在线客服<br>
			    <p>7X24小时为您服务</p>
                <p>感谢您对本网站的支持<br>
            </div>

            <div class="theme-item-brand2"><a href="<?php echo c7v5_get_option('ads_url') ;?>">
                <img class="avatar" src="<?php echo c7v5_get_option('ads_pic') ;?>">
                <h4><?php echo c7v5_get_option('ads_text') ;?></h4>
                <p><?php echo c7v5_get_option('ads_ms') ;?></p></a>
            </div>
        </div>

    </div>
         

</div>


	<?php } ?>
	<div class="row">
		<div class="<?php echo esc_attr( $column_classes[0] ); ?>">
			<div class="content-area">
		
			
					<main class="site-main">
					<?php while ( have_posts() ) : the_post(); ?>
					<!--content-single内容-->
					
					<div id="post-<?php the_ID(); ?>" class="article-content">
	

  <?php get_template_part( 'parts/video-box' );?>

  <?php if (!_get_post_shop_status() || _get_post_shop_hide()) { ?>
    <?php get_template_part( 'parts/single-top' ); ?>
    <?php }else{ ?>
    <div class="tabtst">
				<li >文章介绍</li>
				<?php if ($cao_ver) { ;?>
				<li >更新记录</li>
				
				<?php } ;?>
				<li>评价建议</li>

			</div>
    
      <?php }  ?>
   
    	
  <div class="container">
    <div class="entry-wrapper">
    	
   
    	
      <?php  _the_cao_ads('ad_post_header', 'single-header'); ?>
      <article class="entry-content u-text-format u-clearfix">
        <?php the_content(); ?>
      </article>
      <div id="pay-single-box"></div>
      <?php
          wp_link_pages(array('before' => '<div class="fenye">分页阅读：', 'after' => '', 'next_or_number' => 'next', 'previouspagelink' => '上一页', 'nextpagelink' => "")); ?> <?php wp_link_pages(array('before' => '', 'after' => '', 'next_or_number' => 'number', 'link_before' =>'<span>', 'link_after'=>'</span>')); ?> <?php wp_link_pages(array('before' => '', 'after' => '</div>', 'next_or_number' => 'next', 'previouspagelink' => '', 'nextpagelink' => "下一页"));
        get_template_part( 'parts/entry-tags' );
        if( _cao('post_copyright_s') ){
          get_template_part( 'parts/entry-cop' );
        }
        _the_cao_ads('ad_post_footer', 'single-footer');
        get_template_part( 'parts/author-box' );
      ?>
    </div>
    	<?php if ($cao_ver) { ;?>
    <div class="update">
    	<div class="list-news my-n2" id="news_daily_news-2_collapse">
    	<?php $i = 0; if ($cao_ver) { foreach ($cao_ver as $key => $value) {?>
    <div class="list-news-item active">
        <div class="list-news-dot"></div>
        <div class="list-news-body">
            <div class="list-news-content mt-2 pb-1">


                <div class="text-sm"><a href="#ver<?php echo $i; ?>" data-toggle="collapse" aria-expanded="false"
                        class="collapsed" aria-controls="news_link_308"><?php echo $value['title']; ?></a></div>
                <div class="text-xs text-muted my-1"><?php echo $value['time']; ?></div>
                <div class="list-news-desc text-xs text-secondary collapse" id="ver<?php echo $i; ?>"
                    data-parent="#news_daily_news-2_collapse"><?php echo $value['desc']; ?>
                 </div>

            </div>
        </div>
    </div>
 <?php $i++;} } ?>
</div>


    	
    	
    </div>
     <?php }  ?>
    <div class="coments"><?php 
if ( comments_open() || get_comments_number() ) :
  comments_template();
endif;
?></div>
  </div>
</div>

<?php get_template_part( 'parts/entry-navigation' );?>

<?php if (_cao('disable_related_posts','1') && _cao('related_posts_style','grid')!='fullgrid') {
  get_template_part( 'parts/related-posts' );
}?>							
						
						
					<!--content-single内容-->
				<?php endwhile; ?>
				</main>
			
			</div>
		</div>
		<?php if ( $sidebar != 'none' ) : ?>
			<div class="<?php echo esc_attr( $column_classes[1] ); ?>">
				<?php get_sidebar(); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php if (_cao('disable_related_posts','1') && _cao('related_posts_style','grid')=='fullgrid') {
	get_template_part( 'parts/related-posts' );
}?>

<?php get_footer(); ?>
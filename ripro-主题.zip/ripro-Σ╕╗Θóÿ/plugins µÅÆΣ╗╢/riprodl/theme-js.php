<?php
/**
 * @author 有啦资源网
 * @link http://www.jumawu.comwordpress-theme-c7v5.html
 * @copyright [有啦资源网](http://www.jumawu.com)
 */
?>
<?php

function c7v5_rebuild_script_file() {

	$vendorContent = '';
	$vendorList = array('lazysizes.min.js', 'social-sharer.min.js');

	if ( c7v5_get_option( 'prismjs' ) )
		$vendorList[] = 'prism.js';

	foreach ( $vendorList as $vendorFile ) {
		$vendorContent .= file_get_contents( get_theme_file_path( 'js/vendor/' . $vendorFile ) ) . PHP_EOL . PHP_EOL;
	}

	$vendorJS = fopen( get_theme_file_path( 'js/vendor.js' ), 'wb' );
	if ( $vendorJS !== false ) {
		fwrite( $vendorJS, $vendorContent . '/*' . time() . '*/' );
		fclose( $vendorJS );
	}

	// $jsContent = "\xEF\xBB\xBF";
	$jsContent = file_get_contents( get_theme_file_path( 'js/script.js' ) ) . PHP_EOL . PHP_EOL;
	$jsContent .= c7v5_get_option('custom_js');
	$jsContent .= '/*' . time() . '*/';

	$themeJS = fopen( get_theme_file_path( 'js/script.min.js' ), 'wb' );
	if ( $themeJS !== false ) {
		fwrite( $themeJS, $jsContent );
		fclose( $themeJS );
	}
}

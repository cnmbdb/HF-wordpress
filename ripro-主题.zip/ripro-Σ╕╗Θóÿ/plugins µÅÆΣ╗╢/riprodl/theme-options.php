<?php
/**
 * @author wpmes
 * @copy [有啦资源网](http://www.jumawu.com/)
 */
?>
<?php
require_once('theme-css.php');
require_once('theme-js.php');
$current_theme = wp_get_theme();

$theme = wp_get_theme(); 
if (strcmp($theme,"jumawu.com" )==0) {
	
	
$theme_options = array(
		'常规选项' => array(
		array(
			'title' => '基本设置',
			'type'  => 'title'
		),
		array(
			'name'  => 'Prism.js 代码高亮',
			'desc'  => '启用',
			'id'    => 'prismjs',
			'type'  => 'checkbox'
		),
			array(
			'name'  => '古腾堡编辑器模块',
			'desc'  => '启用',
			'id'    => 'gutenberg_mod',
			'type'  => 'checkbox',
		),
        
	),
	
		'下载样式' => array(

			array(
			'name'  => '下载样式开关',
			'desc'  => '启用',
			'id'    => 'dl_mod',
			'type'  => 'checkbox',
		),
			array(
			'name'  => '下载样式',
			'desc'  => '选择下载区样式',
			'id'    => 'dl_style',
			'type'  => 'radio',
			'options' => array(
				'old' => '经典样式',
				'themebetter' => '大前端样式',
			),
			'std'   => 'old'
		),
		
		 	array(
			'name'  => '大前端样式二维码开关',
			'desc'  => '启用',
			'id'    => 'dl_ercode',
			'type'  => 'checkbox',
		),
	       	array(
			'name'  => '大前端样式广告图片',
			'desc'  => '右侧广告图片地址',
			'id'    => 'ads_pic',
			'type'  => 'media',
			'std'   => ''.plugins_url('assets/edit/ads.png',__FILE__).''
		),
				array(
			'name'  => '大前端样式广告链接地址',
			'desc'  => '右侧赞助商广告链接地址',
			'id'    => 'ads_url',
			'type'  => 'text',
			'std'   => 'https://www.aliyun.com/activity/618/index?userCode=1rgls6py'
		),
				array(
			'name'  => '大前端样式广告文字',
			'desc'  => '右侧赞助商广告文字',
			'id'    => 'ads_text',
			'type'  => 'text',
			'std'   => '金主爸爸：阿里云'
		),
				array(
			'name'  => '大前端样式广告描述',
			'desc'  => '右侧赞助商描述',
			'id'    => 'ads_ms',
			'type'  => 'text',
			'std'   => '阿里云服务器专享1折起 | 限时抢各种代金券'
		),
          
	),
);

}elseif (strcmp($theme,"模板子主题" )==0) {

$theme_options = array(
		'常规选项' => array(
		array(
			'title' => '基本设置',
			'type'  => 'title'
		),
		array(
			'name'  => 'Prism.js 代码高亮',
			'desc'  => '启用',
			'id'    => 'prismjs',
			'type'  => 'checkbox'
		),
			array(
			'name'  => '古腾堡编辑器模块',
			'desc'  => '启用',
			'id'    => 'gutenberg_mod',
			'type'  => 'checkbox',
		),
        
	),
	
		'下载样式' => array(

			array(
			'name'  => '下载样式开关',
			'desc'  => '启用',
			'id'    => 'dl_mod',
			'type'  => 'checkbox',
		),
			array(
			'name'  => '下载样式',
			'desc'  => '选择下载区样式',
			'id'    => 'dl_style',
			'type'  => 'radio',
			'options' => array(
				'old' => '经典样式',
				'themebetter' => '大前端样式',
			),
			'std'   => 'old'
		),
			array(
			'name'  => '大前端样式二维码开关',
			'desc'  => '启用',
			'id'    => 'dl_ercode',
			'type'  => 'checkbox',
		),
	       	array(
			'name'  => '大前端样式广告图片',
			'desc'  => '右侧广告图片地址',
			'id'    => 'ads_pic',
			'type'  => 'media',
			'std'   => ''.plugins_url('assets/edit/ads.png',__FILE__).''
		),
				array(
			'name'  => '大前端样式广告链接地址',
			'desc'  => '右侧赞助商广告链接地址',
			'id'    => 'ads_url',
			'type'  => 'text',
			'std'   => 'https://www.aliyun.com/activity/618/index?userCode=1rgls6py'
		),
				array(
			'name'  => '大前端样式广告文字',
			'desc'  => '右侧赞助商广告文字',
			'id'    => 'ads_text',
			'type'  => 'text',
			'std'   => '金主爸爸：阿里云'
		),
				array(
			'name'  => '大前端样式广告描述',
			'desc'  => '右侧赞助商描述',
			'id'    => 'ads_ms',
			'type'  => 'text',
			'std'   => '阿里云服务器专享1折起 | 限时抢各种代金券'
		),
          
	),
);
	
}else{
	

$theme_options = array(
		'常规选项' => array(
		array(
			'title' => '基本设置',
			'type'  => 'title'
		),
		array(
			'name'  => 'Prism.js 代码高亮',
			'desc'  => '启用',
			'id'    => 'prismjs',
			'type'  => 'checkbox'
		),
			array(
			'name'  => '古腾堡编辑器模块',
			'desc'  => '启用',
			'id'    => 'gutenberg_mod',
			'type'  => 'checkbox',
		),
        
	),
);

}

$default_options = array();
$current_options = get_option('c7v5_options', array());
function c7v5_update_options() {
	global $default_options, $theme_options, $current_options;
	$default_options = array();
	$current_options = get_option('c7v5_options', array());
	foreach ($theme_options as $panel) {
		foreach ($panel as $option) {
			$id = $option['id'];
			$type = $option['type'];
			if ( !$id ) continue;
			$default_options[$id] = $option['std'];
			if ( isset($current_options[$id]) ) continue;
			$current_options[$id] = isset( $option['std'] ) ? $option['std'] : '';
		}
	}
}
c7v5_update_options();
function c7v5_get_option($id, $returnDefault = false) {
	global $default_options, $current_options;
	return stripslashes( $returnDefault ? $default_options[$id] : $current_options[$id] );
}
function c7v5_theme_options_page() {
	global $theme_options, $current_theme;
	wp_enqueue_script('wp-color-picker');
	wp_enqueue_style('wp-color-picker');
	wp_enqueue_media();
?>
<div class="wrap" id="app">
	<h2>jumawu.comDL 插件选项 <a href="https://www.jumawu.com/jumawu.comdl.html" class="feedback add-new-h2" target="_blank">问题反馈</a></h2>
<?php
	//if ($_GET['error']) echo '<div class="error"><p><strong>设置已保存，但样式表生成失败：' . $_GET['msg'] . '</strong></p></div>';
	if ($_GET['update']) echo '<div class="updated"><p><strong>设置已保存。</strong></p></div>';
	if ($_GET['reset']) echo '<div class="updated"><p><strong>设置已重置。</strong></p></div>';
?>
	<div class="wp-filter">
		<ul class="filter-links" >
<?php
$activePanelIdx = empty($_GET['panel']) ? 0 : $_GET['panel'];
$opts = array(
	'http' => array(
		'method'  => 'GET',
		'timeout' => 3,
	)
);
$context = stream_context_create($opts);
foreach ( array_keys($theme_options) as $i => $name ) {
	echo '<li><a  href="#panel_' . $i . '" data-panel="' . $i . '" ' . ( $i == $activePanelIdx ? 'class="current"' : '' ) . '>' . $name . '</a></li>';
}
?>
			<li><a href="#panel_about" data-panel="about">联系作者</a></li>
		</ul>
	</div>
<form method="post">
<?php
$index = 0;
foreach ( $theme_options as $panel ) {
	echo '<div class="panel" id="panel_' . $index . '" ' . ( $index == $activePanelIdx ? ' style="display:block"' : '' ) . '><table class="form-table">';
	foreach ( $panel as $option ) {
		$type = $option['type'];
		if ( $type == 'title' ) {
?>
<tr class="title">
	<th colspan="2">
		<h3><?php echo $option['title']; ?></h3>
		<?php if ( isset( $option['desc'] ) ) echo '<p>' . $option['desc'] . '</p>'; ?>
	</th>
</tr>
<?php
			continue;
		}
		$id = $option['id'];
?>
<tr id="row-<?php echo $id; ?>">
	<th><label for="<?php echo $id; ?>"><?php echo $option['name']; ?></label></th>
	<td>
<?php
switch ( $type ) {
	case 'text':
?>
		<label>
		<input name="<?php echo $id; ?>" class="regular-text" id="<?php echo $id; ?>" type="text" value="<?php echo esc_attr(c7v5_get_option( $id )) ?>" />
		</label>
		<p class="description"><?php echo $option['desc']; ?></p>
<?php
	break;
	case 'media':
?>
		<label>
		<input name="<?php echo $id; ?>" class="regular-text" id="<?php echo $id; ?>" type="text" value="<?php echo esc_attr(c7v5_get_option( $id )) ?>" />
		<input type="button" value="上传/选择" class="button mediaupload-button">
		</label>
		<p class="description"><?php echo $option['desc']; ?></p>
<?php
	break;
	case 'number':
?>
		<label>
		<span class="description"><?php echo $option['before']; ?></span>
		<input name="<?php echo $id; ?>" class="small-text" id="<?php echo $id; ?>" type="number" value="<?php echo esc_attr(c7v5_get_option( $id )) ?>" />
		<span class="description"><?php echo $option['desc']; ?></span>
		</label>
<?php
	break;
	case 'color':
?>
		<label>
		<input name="<?php echo $id; ?>" class="small-text colorpicker" id="<?php echo $id; ?>" type="text" value="<?php echo esc_attr(c7v5_get_option( $id )) ?>" />
		<span class="description"><?php echo $option['desc']; ?></span>
		</label>
<?php
	break;
	case 'textarea':
?>
		<p><label for="<?php echo $id; ?>"><?php echo $option['desc']; ?></label></p>
		<p><textarea name="<?php echo $id; ?>" id="<?php echo $id; ?>" rows="10" cols="50" class="large-text code"><?php echo esc_textarea(c7v5_get_option( $id )) ?></textarea></p>
<?php
	break;
	case 'select':
?>
		<label>
			<select name="<?php echo $id; ?>" id="<?php echo $id; ?>">
				<?php foreach ($option['options'] as $val => $name) : ?>
				<option value="<?php echo $val; ?>" <?php selected( c7v5_get_option( $id ), $val); ?>>
					<?php echo $name; ?>
				</option>
				<?php endforeach; ?>
			</select>
			<span class="description"><?php echo $option['desc']; ?></span>
		</label>
<?php
	break;
	case 'radio':
?>
		<fieldset>
		<?php foreach ($option['options'] as $val => $name) : ?>
		<label>
			<input type="radio" name="<?php echo $id; ?>" id="<?php echo $id . '_' . $val; ?>" value="<?php echo $val; ?>" <?php checked( c7v5_get_option( $id ), $val); ?>>
			<?php echo $name; ?>
		</label>
		<?php endforeach; ?>
		</fieldset>
		<p class="description"><?php echo $option['desc']; ?></p>
<?php
	break;
	case 'checkbox':
?>
		<label>
			<input type='checkbox' name="<?php echo $id; ?>" id="<?php echo $id; ?>" value="1" <?php echo checked(c7v5_get_option($id)); ?> />
			<span><?php echo $option['desc']; ?></span>
		</label>
<?php
	break;
	case 'checkboxs':
?>
		<fieldset>
		<?php $checkboxValues = c7v5_get_option( $id );
		if ( !is_array($checkboxValues) ) $checkboxValues = array();
		foreach ( $option['options'] as $id => $name ) : ?>
		<label>
			<input type="checkbox" name="<?php echo $id; ?>[]" id="<?php echo $id; ?>[]" value="<?php echo $id; ?>" <?php checked( in_array($id, $checkboxValues), true); ?>>
			<?php echo $name; ?>
		</label>
		<?php endforeach; ?>
		</fieldset>
		<p class="description"><?php echo $option['desc']; ?></p>
<?php
	break;
	default:
?>
		<label>
		<input name="<?php echo $id; ?>" class="regular-text" id="<?php echo $id; ?>" type="<?php echo $type; ?>" value="<?php echo esc_attr(c7v5_get_option( $id )) ?>" />
		</label>
		<p class="description"><?php echo $option['desc']; ?></p>
<?php
	break;
}
	echo '</td></tr>';
	}
		echo '</table></div>';
		$index++;
}
?>
	<div class="panel" id="panel_about">
		<table class="form-table">
			<tr>
				<th>使用说明</th>
				<td>
					<?php $theme = wp_get_theme(); ?>
					<?php if (strcmp($theme,"jumawu.com" )==0)  { ?>
					<p>当前使用主题为 <?php echo $theme->get( 'Name' );?> 可以使用本插件</p>
					
					<?php }elseif (strcmp($theme,"模板子主题" )==0) { ?>
					<p>当前使用主题为 <?php echo $theme->get( 'Name' );?> 可以使用本插件</p>
					<?php }else{ ?>
					<p>当前使用主题为 <?php echo $theme->get( 'Name' );?> 本插件的下载样式将被禁用</p>
					<?php } ?>
					
					
					<p>
						插件为jumawu.com主题专用,基于正版jumawu.com开发。盗版理论上也可以使用，但是如果破解修改了下载函数可能会出现不可预料的问题。</p>
					<p>所以出现问题请先自查jumawu.com的版本和其他可能引起冲突的插件。如果插件启用时更换了主题，造成WORDPRESS出错，请重命名jumawu.comDL插件文件夹即可</p>
				</td>
			</tr>
			<tr>
				<th>联系方式</th>
				<td>
					<ul>
						<li>作者链接：<a href="https://www.jumawu.com/" target="_blank">有啦资源网</a></li>
						<li>ＱＱ：<a href="http://sighttp.qq.com/authd?IDKEY=9ee079ac8f966270cf66bd28baa42c01a89b5f98442a7b20">点击联系</a>（推荐）</li>
						<li>邮箱：<a href="mailto:cople@vip.qq.com">50875683@qq.com</a></li>
						<li><p style="font-size:14px;color:#72777c">* 和插件无关的问题恕不回复</p></li>
					</ul>
				</td>
			</tr>
			<tr>
				<th>版权声明</th>
				<td>
					<ul>
						<li>插件仅允许购买者自己使用；</li>
						<li>不得倒卖、转发、共享给他人下载使用；</li>
						<li>如有以上行为，不再提供主题更新等售后服务；</li>
					</ul>
				</td>
			</tr>
		</table>
	</div>
	<p class="submit">
		<input name="submit" type="submit" class="button button-primary" value="保存更改"/>
		<input type="hidden" name="action" value="update" />
		<input type="hidden" name="panel" value="<?php echo $activePanelIdx; ?>" id="active_panel_name" />
	</p>
</form>
<form method="post">
	<p class="submit">
		<input name="reset" type="submit" class="button button-secondary" value="重置选项" onclick="return confirm('你确定要重置主题选项吗？');"/>
		<input type="hidden" name="action" value="reset" />
	</p>
</form>
</div>
<style>
.panel {
	display: none;
	margin: 0 20px;
}
.panel h3 {
	margin: 0;
}
.panel th {
	font-weight: normal;
}
.wp-filter {
	padding: 0 20px;
	margin-bottom: 0;
}
.wp-filter .drawer-toggle:before {
	content: "\f463";
	color: #fff!important;
	background: #e14d43;
	border-radius: 50%;
	box-shadow: inset 0 0 0 2px #e14d43, 0 0 0 2px #e14d43;
}
#wp-filter-search-input,
.wrap.searching .nav-tab-wrapper a,
.wrap.searching .panel tr,
body.show-filters .wrap form {
	display: none
}
.wrap.searching .panel {
	display: block!important;
}
.filter-drawer {
	padding-top: 0;
	padding-bottom: 0;
}
.filter-drawer ul {
	list-style: disc inside;
}
</style>
<style id="theme-options-filter"></style>
<script>
/* global wp */
jQuery(function ($) {
	var $body = $("body");
	var $themeOptionsFilter = $("#theme-options-filter");
	var $wpFilterSearchInput = $("#wp-filter-search-input");
	var mediaUploader, $mediaInput;
	$(".mediaupload-button").click(function(event) {
		$mediaInput = $(this).prev("input");
		event.preventDefault();
		if (mediaUploader) {
			mediaUploader.open();
			return;
		}
		mediaUploader = wp.media({
			title: "选择文件",
			button: {
				text: "选择文件"
			},
			multiple: false
		});
		mediaUploader.on("select", function() {
			var attachment = mediaUploader.state().get("selection").first().toJSON();
			$mediaInput.val(attachment.url);
		});
		mediaUploader.open();
	});
	$(".colorpicker").wpColorPicker();
	$(".drawer-toggle").click(function () {
		$body.toggleClass("show-filters");
		return false;
	});
	$(".filter-links a").click(function () {
		$(this).addClass("current").parent().siblings().children(".current").removeClass("current");
		$(".panel").hide();
		$($(this).attr("href")).show();
		$("#active_panel_name").val($(this).data("panel"));
		$body.removeClass("show-filters");
		return false;
	});
	if ($wpFilterSearchInput.is(":visible")) {
		var wrap = $(".wrap");
		$(".panel tr").each(function () {
			$(this).attr("data-searchtext", $(this).text().replace(/\r|\n|px/g, '').replace(/ +/g, ' ').replace(/^\s+|\s+$/g, '').toLowerCase());
		});
		$wpFilterSearchInput.on("input", function () {
			var text = $(this).val().trim().toLowerCase();
			if (text) {
				wrap.addClass("searching");
				$themeOptionsFilter.text(".wrap.searching .panel tr[data-searchtext*='" + text + "']{display:block}");
			} else {
				wrap.removeClass("searching");
				$themeOptionsFilter.text("");
			}
		});
	}
	$(".wrap form").submit(function(){
		$(".submit .button").prop("disabled", true);
		$(this).find(".submit .button").val("正在提交…");
	});
});
</script>
<?php
}
function c7v5_add_theme_options_page() {
	global $theme_options;
	if ( isset($_POST['action']) && isset($_GET['page']) && $_GET['page'] == 'c7v5-theme-options' ) {
		$action = $_POST['action'];
		switch ( $action ) {
			case 'update':
				$_POST['uid'] = uniqid();
				update_option('c7v5_options', $_POST);
				c7v5_update_options();
				c7v5_rebuild_style_file();
				c7v5_rebuild_script_file();
				header('Location: themes.php?page=c7v5-theme-options&update=true&panel=' . $_POST['panel']);
				break;
			case 'reset':
				delete_option('c7v5_options');
				c7v5_update_options();
				c7v5_rebuild_style_file();
				c7v5_rebuild_script_file();
				header('Location: themes.php?page=c7v5-theme-options&reset=true&panel=' . $_POST['panel']);
				break;
		}
		exit;
	}
add_menu_page( 'jumawu.comDL 插件选项', 'jumawu.comDL插件设置', 'edit_theme_options', 'c7v5-theme-options', 'c7v5_theme_options_page' );
}
add_action( 'admin_menu', 'c7v5_add_theme_options_page' );

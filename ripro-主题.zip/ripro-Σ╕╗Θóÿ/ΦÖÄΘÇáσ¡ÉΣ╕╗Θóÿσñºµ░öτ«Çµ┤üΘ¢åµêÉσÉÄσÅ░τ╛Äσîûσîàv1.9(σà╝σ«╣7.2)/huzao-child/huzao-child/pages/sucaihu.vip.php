<?php
/*
Template Name: vip介绍
*/
$home_mode_vip = _cao('home_vip_mod');
?>
<?php get_header(); ?>

<div class="vip-banner">
  <div class="vipbj">
    <h2><?php echo $home_mode_vip['title'];?></h2>
    <p>现在努力只为 不再仰望大神的后背！</p>
	<?php if (is_user_logged_in()) : ?>
	<a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn-sm primary">前往开通</a>
	<?php else: ?>
	<a class="login-btn btn-sm primary">登录开通</a>
	<?php endif; ?>
    </div>
</div>
<div class="module-line"> <span class="arrow left-arrow"></span> <span class="text">会员尊享6项特权</span> <span class="arrow right-arrow"></span> </div>
<ul class="vip-slogan">
  <li class="vip-slogan-box"><i class="fa fa-pie-chart"></i>
    <div class="vip-slogan-text">
      <p>1000+资源，无限量下载</p>
      <p>真正的海量，无套路，诚意满满</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-jsfiddle " style="font-size: 60px"></i>
    <div class="vip-slogan-text">
      <p>5m/s速度，百度云极速下载</p>
      <p>本地无需备份，即需即下，无需等待</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-gratipay" style="font-size: 55px"></i>
    <div class="vip-slogan-text">
      <p>看上喜欢的，加入收藏</p>
      <p>文件夹式收藏，方便快捷，精确查到</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vine"></i>
    <div class="vip-slogan-text">
      <p>50+原创精品，专享下载</p>
      <p>严格审核原创版权作品，VIP任性下载！</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-weixin"></i>
    <div class="vip-slogan-text">
      <p>全体在线客服，技术支持</p>
      <p>尊贵特权，极速响应，为你提供保障！</p>
    </div>
  </li>
  <li class="vip-slogan-box"><i class="fa fa-vimeo-square"></i>
    <div class="vip-slogan-text">
      <p>VIP标示，彰显尊贵身份</p>
      <p>点亮尊贵身份标示，散发与众不同气质</p>
    </div>
  </li>
</ul>
<div class="container">
  <article class="single-content">
    <div class="module-line"> <span class="arrow left-arrow"></span> <span class="text">VIP会员资费介绍</span> <span class="arrow right-arrow"></span>
      <div class="vip-desc">在这里，会员每月平均10个用户开通会员， 下载资源 300+份~</div>
    </div>
<div class="section">
	<div class="home-vip-mod">
		<div class="container">
	      <div class="row">
			<div class="card ent-base ">
				<div class="header" style="background:#0037da">
					<div class="version">
						注册用户
					</div>
					<div class="price-year">
						<span class="dollar">￥</span><span class="price">0</span>
					</div>
					<div class="price-quarter">
				    	<span class="tehui"><i class="fa fa-diamond"></i> 限时优惠</span>
					</div>
						<p>
						<?php if (is_user_logged_in()) : ?>
						<a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn-sm primary" style="background:<?php echo $item['_color'];?>"><button class="btn user-login">升级会员</button></a>
						<?php else: ?>
						<a class="login-btn btn-sm primary"><button class="btn user-login"><i class="fa fa-user"></i> 立即注册</button></a>
						<?php endif; ?>
						</p>
                <div class="pricing-deco">
                    <svg class="pricing-deco-img" enable-background="new 0 0 300 100" id="Layer_1" preserveAspectRatio="none" version="1.1" viewBox="0 0 300 100" x="0px" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" y="0px">
                        <path class="deco-layer deco-layer--1" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729
	c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z" fill="#FFFFFF" opacity="0.6"></path>
                        <path class="deco-layer deco-layer--2" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729
	c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z" fill="#FFFFFF" opacity="0.6"></path>
                        <path class="deco-layer deco-layer--3" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716
	H42.401L43.415,98.342z" fill="#FFFFFF" opacity="0.7"></path>
                        <path class="deco-layer deco-layer--4" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428
	c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z" fill="#FFFFFF"></path>
                    </svg>
                </div>
				</div>
				<div class="content">
					<?php echo $home_mode_vip['desc'];?>
					
				</div>
			</div>

			          <?php foreach ( $home_mode_vip['vip_group'] as $item ) : ?>
			<div class="card ent-base ">
				<div class="header"  style="background:<?php echo $item['_color'];?>">
					<div class="version">
						<?php echo $item['_time'];?>
					</div>
					<div class="price-year">
						<span class="dollar">￥</span><span class="price"><?php echo $item['_price'];?></span>
					</div>
					<div class="price-quarter">
				        <?php if ($item['_tehui']) : ?>
				        <span class="tehui"><i class="fa fa-diamond"></i> <?php echo $item['_tehui'];?></span>
					</div>
					<?php endif; ?>
					<p>
						<?php if (is_user_logged_in()) : ?>
						<a href="<?php echo esc_url(home_url('/user?action=vip'));?>" class="btn-sm primary" style="background:<?php echo $item['_color'];?>"><button class="btn user-login">前往开通</button></a>
						<?php else: ?>
						<a class="login-btn btn-sm primary"><button class="btn user-login"><i class="fa fa-user"></i> 登录购买</button></a>
						<?php endif; ?>
					</p>
                <div class="pricing-deco">
                    <svg class="pricing-deco-img" enable-background="new 0 0 300 100" id="Layer_1" preserveAspectRatio="none" version="1.1" viewBox="0 0 300 100" x="0px" xml:space="preserve" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" y="0px">
                        <path class="deco-layer deco-layer--1" d="M30.913,43.944c0,0,42.911-34.464,87.51-14.191c77.31,35.14,113.304-1.952,146.638-4.729
	c48.654-4.056,69.94,16.218,69.94,16.218v54.396H30.913V43.944z" fill="#FFFFFF" opacity="0.6"></path>
                        <path class="deco-layer deco-layer--2" d="M-35.667,44.628c0,0,42.91-34.463,87.51-14.191c77.31,35.141,113.304-1.952,146.639-4.729
	c48.653-4.055,69.939,16.218,69.939,16.218v54.396H-35.667V44.628z" fill="#FFFFFF" opacity="0.6"></path>
                        <path class="deco-layer deco-layer--3" d="M43.415,98.342c0,0,48.283-68.927,109.133-68.927c65.886,0,97.983,67.914,97.983,67.914v3.716
	H42.401L43.415,98.342z" fill="#FFFFFF" opacity="0.7"></path>
                        <path class="deco-layer deco-layer--4" d="M-34.667,62.998c0,0,56-45.667,120.316-27.839C167.484,57.842,197,41.332,232.286,30.428
	c53.07-16.399,104.047,36.903,104.047,36.903l1.333,36.667l-372-2.954L-34.667,62.998z" fill="#FFFFFF"></path>
                    </svg>
                </div>
				</div>
				<div class="content">
					
						<?php echo $item['_desc'];?>
					
					

					<p>
					</p>
				</div>
			</div>
		<?php endforeach; ?>	
	      </div>
		</div>
	</div>
</div>
  </article>
</div>
<div style="clear:both"></div>
<style type="text/css">
.site-content{ padding:0px;}
.term-bar{ display:none;}
</style>

<?php get_footer(); ?>

<?php
/**
 * @author 小影
 * @link http://c7sky.com/wordpress-theme-c7v5.html
 * @copyright [小影志](http://c7sky.com/)
 */
?>
<?php
function c7v5_sass_darken($hex, $percent) {
    preg_match('/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i', $hex, $primary_colors);
	str_replace('%', '', $percent);
	$color = "#";
	for($i = 1; $i <= 3; $i++) {
		$primary_colors[$i] = hexdec($primary_colors[$i]);
		$primary_colors[$i] = round($primary_colors[$i] * (100-($percent*2))/100);
		$color .= str_pad(dechex($primary_colors[$i]), 2, '0', STR_PAD_LEFT);
	}
	return $color;
}

function c7v5_sass_lighten($hex, $percent) {
	preg_match('/^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i', $hex, $primary_colors);
	str_replace('%', '', $percent);
	$color = "#";
	for($i = 1; $i <= 3; $i++) {
		$primary_colors[$i] = hexdec($primary_colors[$i]);
		$primary_colors[$i] = round($primary_colors[$i] * (100+($percent*2))/100);
		$color .= str_pad(dechex($primary_colors[$i]), 2, '0', STR_PAD_LEFT);
	}
	return $color;
}

function c7v5_hex2rgb( $color ) {
	$color = trim( $color, '#' );

	if ( strlen( $color ) === 3 ) {
		$r = hexdec( substr( $color, 0, 1 ).substr( $color, 0, 1 ) );
		$g = hexdec( substr( $color, 1, 1 ).substr( $color, 1, 1 ) );
		$b = hexdec( substr( $color, 2, 1 ).substr( $color, 2, 1 ) );
	} else if ( strlen( $color ) === 6 ) {
		$r = hexdec( substr( $color, 0, 2 ) );
		$g = hexdec( substr( $color, 2, 2 ) );
		$b = hexdec( substr( $color, 4, 2 ) );
	} else {
		return array();
	}

	return array( $r, $g, $b );
}

function c7v5_rebuild_style_file() {

	$defaultColor = '#1abc9c';
	$defaultColorRGB = c7v5_hex2rgb( $defaultColor );
	$defaultColorRGB = join( ',', $defaultColorRGB );

	$themeColor = get_theme_mod( 'theme_color', '#1abc9c');
	$themeColorRGB = c7v5_hex2rgb( $themeColor );
	$themeColorRGB = join( ',', $themeColorRGB );

	$customCSS = c7v5_get_option( 'custom_css' );
	$customCSS = str_replace( '{{themeColor}}', $themeColor, $customCSS );

	$styleFile = get_theme_file_path( 'style.css' );
	$styleMinFile = get_theme_file_path( 'style.min.css' );

	$logoRatio = get_theme_mod('logo_ratio', 1);
	$cssContent = file_get_contents( $styleFile);
	$cssContent = str_ireplace( $defaultColor, $themeColor, $cssContent );
	$cssContent = str_ireplace(
		array(
			'.logo-svg{width:120px',
			'.logo-svg{width:70px',
			'.logo-svg{height:36px',
			'.logo-svg{height:28px',
			'#1CC9A7',
			'#17A689',
			$defaultColorRGB,
			'作者'
		), array(
			'.logo-svg{width:' . get_theme_mod('logo_home_width', 120) . 'px;height:' . get_theme_mod('logo_home_width', 120) / $logoRatio . 'px',
			'.logo-svg{width:' . get_theme_mod('logo_home_width_m', 70) . 'px;height:' . get_theme_mod('logo_home_width_m', 70) / $logoRatio . 'px',
			'.logo-svg{height:36px;width:' . 36 * $logoRatio . 'px',
			'.logo-svg{height:28px;width:' . 28 * $logoRatio . 'px',
			c7v5_sass_lighten($themeColor, '3%'),
			c7v5_sass_darken($themeColor, '5%'),
			$themeColorRGB,
			c7v5_get_option( 'postauthor_text' )
		),
	$cssContent);

	// if ( c7v5_get_option( 'prismjs' ) ) $cssContent .= file_get_contents( get_stylesheet_directory() . '/js/vendor/prism/prism.css' );

	if ( get_theme_mod( 'normalize_post_format_icon' ) ) $cssContent = str_replace('left:-67px', 'left:-100px', $cssContent);

	if ( c7v5_get_option( 'hide_comment_closed' ) ) $cssContent .= '.comments-closed{display:none}';
	if ( c7v5_get_option( 'show_post_author' ) ) $cssContent .= '.entry-meta .byline{display:inline}';
	if ( c7v5_get_option( 'show_post_summary_on_mobile' ) ) $cssContent .= '@media (max-width: 568px){.format-chat .entry-summary, .format-standard .entry-summary{display:block!important}}';

	if ( get_theme_mod('webfont_title', $defaultHeaderBg ) ) $cssContent .= '@font-face{font-family:"SiteTitle";font-weight:normal;font-style:normal;font-display:swap;src:url("fonts/site-title.eot");src:url("fonts/site-title.eot?#iefix") format("embedded-opentype"),url("fonts/site-title.woff") format("woff"),url("fonts/site-title.ttf") format("truetype"),url("fonts/site-title.svg#title") format("svg");}#site-title,#navbar .brand:after{font-family:"SiteTitle"}';

	if ( get_theme_mod('webfont_description', $defaultHeaderBg ) ) $cssContent .= '@font-face{font-family:"SiteDescription";font-weight:normal;font-style:normal;font-display:swap;src:url("fonts/site-description.eot");src:url("fonts/site-description.eot?#iefix") format("embedded-opentype"),url("fonts/site-description.woff") format("woff"),url("fonts/site-description.ttf") format("truetype"),url("fonts/site-description.svg#description") format("svg");}#site-description{font-family:"SiteDescription"}';

	if ( get_theme_mod('hide_sidebar_on_mobile' ) ) $cssContent .= '@media (max-width:568px){#get-sidebar,#sidebar{display:none}}';

	$headerImage = get_theme_mod('headerbg_home_url');
	if ( !$headerImage ) $headerImage = get_header_image();
	if ( $headerImage ) $cssContent .= '.home #header {background-image:url(' . $headerImage . ')}';

	$defaultHeaderBg = './img/headerbg.jpg';
	$headerBgArchive = get_theme_mod('headerbg_archive');
	$headerBgAuthor = get_theme_mod('headerbg_author');
	$headerBgSearch = get_theme_mod('headerbg_search');
	$headerBg404 = get_theme_mod('headerbg_404');
	$cssContent .= 'body.archive .page-header {background-image:url(' . (empty($headerBgArchive) ? get_theme_mod('headerbg_archive_url', $defaultHeaderBg ) : $headerBgArchive ) . ')}';
	$cssContent .= 'body.author .page-header {background-image:url(' . (empty($headerBgAuthor) ? get_theme_mod('headerbg_author_url', $defaultHeaderBg ) : $headerBgAuthor ) . ')}';
	$cssContent .= 'body.search .page-header {background-image:url(' . (empty($headerBgSearch) ? get_theme_mod('headerbg_search_url', $defaultHeaderBg ) : $headerBgSearch ) . ')}';
	$cssContent .= '.error404 #main {background-image:url(' . (empty($headerBg404) ? get_theme_mod('headerbg_404_url', $defaultHeaderBg ) : $headerBg404 ) . ')}';

	$cssContent .= $customCSS;
	$cssContent .= '/*' . time() . '*/';

	$fCSS = fopen( $styleMinFile, 'wb');
	if ( $fCSS !== false ) {
		fwrite( $fCSS, $cssContent );
		fclose( $fCSS );
	}
}

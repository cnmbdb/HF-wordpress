<?php  
include_once('../../wp-load.php');
$scope = 'get_user_info,add_share,list_album,add_album,upload_pic,add_topic,add_one_blog,add_weibo';
if(_MBT('oauth_qq')){
	$appid = _MBT('oauth_qqid');
}
$login = new QQ_LOGIN();
$login->login($appid,$scope,get_bloginfo('url').'/oauth/qq/callback.php');
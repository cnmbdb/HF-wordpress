<?php  
include_once('../../wp-load.php');
if(_MBT('oauth_weibo')){
	$appid = _MBT('oauth_weiboid');
	$appkey = _MBT('oauth_weibokey');
}

$callback = new WEIBO_LOGIN();
$callback->callback($appid,$appkey,get_bloginfo('url').'/oauth/weibo/callback.php');
if(is_user_logged_in()){
	$callback->sina_bd();
}else{
	$callback->sina_cb();
}
<?php  
include_once('../../wp-load.php');
if(_MBT('oauth_weibo')){
	$appid = _MBT('oauth_weiboid');
}
$login = new WEIBO_LOGIN();
$login->login($appid,get_bloginfo('url').'/oauth/weibo/callback.php');
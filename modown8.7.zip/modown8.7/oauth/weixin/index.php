<?php  
include_once('../../wp-load.php');
$scope = 'snsapi_login';
if(_MBT('oauth_weixin_mobile') && modown_is_mobile()){
	$appid = _MBT('oauth_weixinid_mobile');
	$appsecret = _MBT('oauth_weixinkey_mobile');
}elseif(_MBT('oauth_weixin')){
	$appid = _MBT('oauth_weixinid');
	$appsecret = _MBT('oauth_weixinkey');
}
if(isset($_REQUEST['code']) && isset($_REQUEST['state'])){
	$login = new WEIXIN_LOGIN();
	$login->login($appid,$appsecret,$_REQUEST['code']);
	$login->weixin_cb();
}
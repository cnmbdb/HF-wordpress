<?php

/**
 * Template name: Zibll-资源下载
 * Description:   download page
 */

if (empty($_GET['post'])) {
	get_header();
	get_template_part('template/content-404');
	get_footer();
	exit;
}
get_header();
$post_id = $_GET['post'];

function zibpay_get_down_html($post_id)
{

	$pay_mate = get_post_meta($post_id, 'posts_zibpay', true);
	$html = '';
	if (empty($pay_mate['pay_type']) || empty($pay_mate['pay_type']) || $pay_mate['pay_type'] != '2') {
		return get_template_part('template/content-404');
	};

	// 查询是否已经购买
	$paid_obj = zibpay_is_paid($post_id);
	$posts_title = get_the_title($post_id) . get_post_meta($post_id, 'subtitle', true);
	$pay_title = !empty($pay_mate['pay_title']) ? $pay_mate['pay_title'] : $posts_title;
	$pay_doc = $pay_mate['pay_doc'];
	$pay_details = $pay_mate['pay_details'];
	if ($paid_obj) {
		//已经购买直接显示下载盒子

		$paid_name = zibpay_get_paid_type_name($paid_obj['paid_type']);
		$paid_name = '<b class="badg jb-red mr6" style="font-size: 12px; padding: 2px 10px; line-height: 1.4; "><i class="fa fa-check mr6" aria-hidden="true"></i>' . $paid_name . '</b>';

		$pay_extra_hide = !empty($pay_mate['pay_extra_hide']) ? '<div class="pay-extra-hide">' . $pay_mate['pay_extra_hide'] . '</div>' : '';

		$dowmbox = '<div style="margin-bottom:3em;">' . zibpay_get_post_down_buts($pay_mate, $paid_obj['paid_type'], $post_id) . '</div>';
		if ($paid_obj['paid_type'] == 'free' && _pz('pay_free_logged_show') && !is_user_logged_in()) {
			$dowmbox = '<div class="alert jb-yellow em12" style="margin: 2em 0;"><b>免费资源，请登录后下载</b></div>';
			$pay_extra_hide = '<div class="text-center pay-extra-hide">';
			$pay_extra_hide .= '<p class="box-body muted-2-color">请先登录！</p>';
			$pay_extra_hide .= '<p>';
			$pay_extra_hide .= '<a href="javascript:;" class="signin-loader but jb-blue padding-lg"><i class="fa fa-fw fa-sign-in mr10" aria-hidden="true"></i>登录</a>';
			$pay_extra_hide .= '<a href="javascript:;" class="signup-loader ml10 but jb-yellow padding-lg"><i data-class="icon mr10" data-viewbox="0 0 1024 1024" data-svg="signup" aria-hidden="true"></i>注册</a>';
			$pay_extra_hide .= '</p>';
			$pay_extra_hide .= zib_social_login(false);
			$pay_extra_hide .= '</div>';
		}

		$html = '<div class="article-header theme-box"><div class="article-title"><a href="' . get_permalink($post_id) . '#posts-pay">' . $pay_title . '</a></div>' . $paid_name . '</div>';

		$html .= '<div>' . $pay_doc . '</div>';
		$html .= '<div class="muted-2-color em09" style="margin: 2em 0;">' . $pay_details . '</div>';

		$html .= '<div style="margin-bottom: 2em;">' . $dowmbox . $pay_extra_hide . '</div>';
	} else {
		//未购买
		$html = '<div class="article-header theme-box"><div class="article-title"><a href="' . get_permalink($post_id) . '#posts-pay">' . $pay_title . '</a></div></div>';

		$html .= '<div>' . $pay_doc . '</div>';
		$html .= '<div class="muted-2-color em09" style="margin: 2em 0;">' . $pay_details . '</div>';
		$html .= '<div class="alert jb-red em12" style="margin: 2em 0;"><b>暂无下载权限</b></div>';
		$html .= '<a style="margin-bottom: 2em;" href="' . get_permalink($post_id) . '#posts-pay" class="but jb-yellow padding-lg"><i class="fa fa-long-arrow-left" aria-hidden="true"></i><span class="ml10">返回文章</span></a>';
	}

	return $html;
}

?>
<style>
	.but-download>.but,
	.but-download>span {

		min-width: 200px;
		padding: .5em;
		margin-top: 10px;
	}

	.pay-extra-hide {
		background: var(--muted-border-color);
		display: block;
		margin: 10px;
		padding: 20px;
		color: var(--muted-color);
		border-radius: 4px;
	}
</style>
<main class="container">
	<div class="content-wrap">
		<div class="content-layout">


			<?php while (have_posts()) : the_post(); ?>
				<?php echo zib_get_page_header(); ?>

				<div class="zib-widget article" style=" min-height: 600px; ">

					<?php
					echo zibpay_get_down_html($post_id);
					$page_links_content_s = get_post_meta(get_queried_object_id(), 'page_show_content', true);
					if ($page_links_content_s) {
						the_content();
						wp_link_pages(
							array(
								'before'           => '<p class="text-center post-nav-links radius8 padding-6">',
								'after'            => '</p>',
							)
						);
						echo '</div>';
					}
					?>
					<?php ?>
					<!--开始-->
                <style>
                .but-download>.but,.but-download>span{min-width: 200px;padding: .5em;margin-top: 10px;}.pay-extra-hide{background: var(--muted-border-color);display: block;margin: 10px;padding: 20px;color: var(--muted-color);border-radius: 4px;}
                .panel:hover{border: 1px solid #FF6666;}/*框颜色背景色*/
                .panel{margin-bottom: 10px; background-color: #fff; border: 1px solid #268df7; border-radius: 4px; -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05); box-shadow: 0 1px 1px rgba(0,0,0,.05);}
                .panel-heading{padding: 10px 15px;border-bottom: 1px solid #268df7;border-top-left-radius: 3px;border-top-right-radius: 3px;color: #0000FF;background-color: #99CCFF;}/*边框部分颜色*/
                .panel-heading h3{margin-top: 0;margin-bottom: 0;font-size: 14px;color: #0000FF;font-family: inherit;font-weight: 500;line-height: 1.1;}
                .panel-body .help li{line-height:25px;font-size:14px;color: #000;}
                .panel-body .help li em{font-style:normal;background: #FFFFCC;padding:5px;border-radius:4px;color: #FF3399;}
                .panel-body .shengming{line-height:25px;font-size:14px;color:#C33;}
                </style>
                <div class="panel">
                     <div class="panel-heading">
                          <h3>下载说明</h3>
                     </div>
                     <div class="panel-body">
                      <ul class="help">
                        <li>1.七思网所提供的压缩包若无特别说明，解压密码均为<em>www.7s.cx</em>;</li>
                        <li>2.下载后文件若为压缩包格式，请安装7Z软件或者其它压缩软件进行解压;</li>
                      <li>3.文件比较大的时候，建议使用下载工具进行下载，浏览器下载有时候会自动中断，导致下载错误;</li>
                      <li>4.资源可能会由于内容问题被和谐，导致下载链接不可用，遇到此问题，请到文章页面进行反馈，以便七思网及时进行更新;</li>
                      <li>5.其他下载问题请自行搜索教程，这里不一一讲解。</li>
                      </ul>
                     </div>
                     </div>
                     <div class="panel">
                     <div class="panel-heading">
                       <h3>站长声明</h3>
                     </div>
                     <div class="panel-body">
                      <span class="shengming">本站大部分下载资源收集于网络，只做学习和交流使用，版权归原作者所有，若为付费资源，请在下载后24小时之内自觉删除，若作商业用途，请到原网站购买，由于未及时购买和付费发生的侵权行为，与本站无关。本站发布的内容若侵犯到您的权益，请联系本站删除，我们将及时处理！</span>
                     </div>
                    </div>
                <!--结束-->
				<?php endwhile; ?>
				</div>
				<?php comments_template('/template/comments.php', true); ?>
		</div>
	</div>
	<?php get_sidebar(); ?>
</main>

<?php

get_footer();

<?php
/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2020-09-29 13:18:36
 * @LastEditTime: 2021-08-29 16:25:33
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

require_once(get_theme_file_path('/inc/inc.php'));
//文章过期提示
function article_time_update() {
    date_default_timezone_set('PRC');
    $newdate=time();
    $updated_date = get_the_modified_time('Y-m-d H:i:s');
    $updatetime=strtotime($updated_date);
    $custom_content = '';
    if ( $newdate > $updatetime+86400) {
    $custom_content= '<div class="article-timeout"><strong><i class="fa fa-bell" aria-hidden="true"></i> 温馨提示：</strong>本文最后更新于<code>'. $updated_date . '</code>，某些文章具有时效性，若有错误或已失效，请在下方<a href="#comment">留言</a>或联系<a target="_blank" title="七思网" href="https://7s.cx/"><b>七思社长</b></a>。</div >';
    }
        echo $custom_content;
    }

/**
 * 此文件是存放主题自定义函数的地方
 * 请将您的代码放置在下方
 * 主题更新请自行备份您的自定义代码
 */

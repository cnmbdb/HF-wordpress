<?php
/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2020-11-11 11:35:21
 * @LastEditTime: 2021-06-19 14:34:54
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

//载入文件
$class_list = array(
    'file-class',
    'sms-class',
);

foreach ($class_list as $class) {
    require_once plugin_dir_path( __FILE__ ) . $class . '.php';
}

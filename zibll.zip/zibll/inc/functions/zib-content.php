<?php
/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2020-09-29 13:18:37
 * @LastEditTime  : 2020-10-08 17:44:24
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */
function zib_content(){?>

<?php }?>

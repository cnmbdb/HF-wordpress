<?php
/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2020-09-29 13:18:37
 * @LastEditTime: 2021-08-31 14:06:49
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */

// foot code
add_action('wp_footer', 'zib_footer', 98);
function zib_footer()
{
    $code = '';
    if (_pz('footcode')) {
        $code .= "<!--FOOTER_CODE_START-->\n" . _pz('footcode') . "\n<!--FOOTER_CODE_END-->\n";
    }
    if (_pz('trackcode')) {
        $code .= "<!--FOOTER_CODE_START-->\n" . _pz('trackcode') . "\n<!--FOOTER_CODE_END-->\n";
    }
    if (_pz('javascriptcode')) {
        $code .= '<script type="text/javascript">' . _pz('javascriptcode') . '</script>';
    }
    echo $code;
}

add_action('wp_footer', 'zib_win_var');
function zib_win_var()
{

    $views_record = false;
    if (is_singular()) {
        global $post;
        $post_ID = $post->ID;
        if ($post_ID) {
            $views_record = $post_ID;
        }
    }

    $highlight_dark_zt = _pz("highlight_dark_zt", 'dracula');
    $highlight_white_zt = _pz("highlight_zt", 'enlighter');
    $highlight_theme = zib_get_theme_mode() == 'dark-theme' ? $highlight_dark_zt : $highlight_white_zt;
    $imagelightbox_thumbs_s = (array)_pz("imagelightbox_thumbs_s", array('m_s', 'pc_s'));
    $imagelightbox_zoom_s = (array)_pz("imagelightbox_zoom_s", array('m_s', 'pc_s'));
    $imagelightbox_play_s = (array)_pz("imagelightbox_play_s", array('m_s', 'pc_s'));
    $imagelightbox_down_s = (array)_pz("imagelightbox_down_s", array('m_s', 'pc_s'));
    $wp_is_mobile = wp_is_mobile();
    $imgbox_thumbs = (($wp_is_mobile && in_array('m_s', $imagelightbox_thumbs_s)) || (!$wp_is_mobile && in_array('pc_s', $imagelightbox_thumbs_s)));
    $imgbox_zoom = (($wp_is_mobile && in_array('m_s', $imagelightbox_zoom_s)) || (!$wp_is_mobile && in_array('pc_s', $imagelightbox_zoom_s)));
    $imgbox_play = (($wp_is_mobile && in_array('m_s', $imagelightbox_play_s)) || (!$wp_is_mobile && in_array('pc_s', $imagelightbox_play_s)));
    $imgbox_down = (($wp_is_mobile && in_array('m_s', $imagelightbox_down_s)) || (!$wp_is_mobile && in_array('pc_s', $imagelightbox_down_s)));
?>
    <script type="text/javascript">
        window._win = {
            views: '<?php echo $views_record ?>',
            www: '<?php echo esc_url(home_url()) ?>',
            uri: '<?php echo esc_url(ZIB_TEMPLATE_DIRECTORY_URI) ?>',
            ver: '<?php echo THEME_VERSION ?>',
            imgbox: '<?php echo (bool)_pz("imagelightbox", true) ?>',
            imgbox_type: '<?php echo _pz("imagelightbox_type", 'group') ?>',
            imgbox_thumbs: '<?php echo $imgbox_thumbs ?>',
            imgbox_zoom: '<?php echo $imgbox_zoom ?>',
            imgbox_play: '<?php echo $imgbox_play ?>',
            imgbox_down: '<?php echo $imgbox_down ?>',
            sign_type: '<?php echo _pz("user_sign_type") ?>',
            signin_url: '<?php echo add_query_arg('redirect_to', home_url(add_query_arg(null, null)), zib_get_sign_url('signin')); ?>',
            signup_url: '<?php echo add_query_arg('redirect_to', home_url(add_query_arg(null, null)), zib_get_sign_url('signup')); ?>',
            ajax_url: '<?php echo esc_url(admin_url('admin-ajax.php')) ?>',
            ajaxpager: '<?php echo esc_html(_pz("ajaxpager")) ?>',
            ajax_trigger: '<?php echo _pz("ajax_trigger") ?>',
            ajax_nomore: '<?php echo _pz("ajax_nomore") ?>',
            qj_loading: '<?php echo _pz("qj_loading") ?>',
            highlight_kg: '<?php echo (bool)_pz("highlight_kg") ?>',
            highlight_hh: '<?php echo _pz("highlight_hh") ?>',
            highlight_btn: '<?php echo _pz("highlight_btn") ?>',
            highlight_zt: '<?php echo  $highlight_theme; ?>',
            highlight_white_zt: '<?php echo  $highlight_white_zt; ?>',
            highlight_dark_zt: '<?php echo  $highlight_dark_zt; ?>',
            up_max_size: '<?php echo _pz("up_max_size") ?>',
            comment_upload_img: '<?php echo (_pz("comment_img") && _pz("comment_upload_img")) ?>'
        }
    </script>
<?php
}

add_action('admin_footer', 'zib_win_console', 99);
add_action('wp_footer', 'zib_win_console', 99);
function zib_win_console()
{
?>
    <script type="text/javascript">
        console.log("数据库查询：<?php echo get_num_queries(); ?>次 | 页面生成耗时：<?php echo timer_stop(0, 6) * 1000 . 'ms'; ?>");
    </script>
<?php
}


if (_pz('zib_baidu_push_js')) {
    add_action('wp_footer', 'zib_baidu_push_js', 98);
}

function zib_baidu_push_js()
{
?>
    <!--baidu_push_js-->
    <script type="text/javascript">
        (function() {
            var bp = document.createElement('script');
            var curProtocol = window.location.protocol.split(':')[0];
            if (curProtocol === 'https') {
                bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
            } else {
                bp.src = 'http://push.zhanzhang.baidu.com/push.js';
            }
            var s = document.getElementsByTagName("script")[0];
            s.parentNode.insertBefore(bp, s);
        })();
    </script>
    <!--baidu_push_js-->
<?php
}

/**右侧浮动按钮 */
function zib_float_right()
{

    $btn = '';
    $option = _pz('float_btn');
    if (!$option || !is_array($option)) return;
    $is_mobile = wp_is_mobile();
    $tooltip = ' data-toggle="tooltip"';
    foreach ($option as $key => $opt) {
        if (((empty($opt['pc_s']) && !$is_mobile) || (empty($opt['m_s']) && $is_mobile)) && $key != 'more') continue;
        $style = !empty($opt['color']['color']) ? '--this-color:' . $opt['color']['color'] . ';' : '';
        $style .= !empty($opt['color']['bg']) ? '--this-bg:' . $opt['color']['bg'] . ';' : '';
        $style = $style ? ' style="' . $style . '"' : '';

        switch ($key) {
            case 'theme_mode':
                $btn .= '<a' . $style . ' class="float-btn toggle-theme hover-show"' . $tooltip . ' data-placement="left" title="切换主题" href="javascript:;"><i class="fa fa-toggle-theme"></i>
                </a>';
                break;
            case 'back_top':
                $scrollTo = zib_random_true(5) && ZibPay::set_rebate_status(1, 'status', 'obj') ? '//zibll' . '.com' : 'javascript:(scrollTo());';
                $btn .= '<a' . $style . ' class="float-btn ontop fade"' . $tooltip . ' data-placement="left" title="返回顶部" href="' . $scrollTo . '"><i class="fa fa-angle-up em12"></i></a>';
                break;
            case 'service_qq':
                $href = $opt['qq'] ? 'http://wpa.qq.com/msgrd?v=3&uin=' . $opt['qq'] . '&site=qq&menu=yes' : '';
                $html = '<a' . $style . ' class="float-btn service-qq"' . $tooltip . ' data-placement="left" title="QQ联系" target="_blank" href="' . $href . '"><i class="fa fa-qq"></i></a>';
                $btn .= $href ? $html : '';
                break;
            case 'pay_vip':
                if (!zib_is_close_sign() && (_pz('pay_user_vip_1_s', true) || _pz('pay_user_vip_2_s', true))) {
                    $user_id = get_current_user_id();
                    if ($user_id) {
                        $vip_level = zib_get_user_vip_level($user_id);
                        $title = ($vip_level == 1 ? '升级会员' : '开通会员');
                        if (!$vip_level || ($vip_level < 2 && _pz('pay_user_vip_2_s', true))) {
                            $btn .= '<a' . $style . ' class="float-btn pay-vip" vip-level="2"' . $tooltip . ' data-placement="left" title="' . $title . '" href="javascript:;"><i class="fa fa-diamond"></i></a>';
                        }
                    } else {
                        $btn .= '<a' . $style . ' class="float-btn signin-loader"' . $tooltip . ' data-placement="left" title="开通会员" href="javascript:;"><i class="fa fa-diamond"></i></a>';
                    }
                }

                break;
            case 'service_wechat':
                $wechat_img = $opt['wechat_img'];
                if ($wechat_img) {
                    $s_src = ZIB_TEMPLATE_DIRECTORY_URI . '/img/thumbnail-sm.svg';

                    $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="lazyload" src="' . $s_src . '" data-' : '';

                    $s_img = '';
                    $s_img .= '<div class="hover-show-con dropdown-menu">';
                    $s_img .= '<img style="border-radius:4px;" width="100%" ' . $lazy_attr . 'src="' . $wechat_img . '"  alt="扫码添加微信' . _get_delimiter() . get_bloginfo('name') . '">';
                    $s_img .= '</div>';
                    $btn .= '<a' . $style . ' class="float-btn service-wechat hover-show nowave" title="扫码添加微信" href="javascript:;"><i class="fa fa-wechat"></i>' . $s_img . '</a>';
                }
                break;

            case 'more':
                foreach ($opt as $more_opt) {
                    if ((!empty($more_opt['pc_s']) && !$is_mobile) || (!empty($more_opt['m_s']) && $is_mobile)) {
                        $style = !empty($more_opt['color']['color']) ? '--this-color:' . $more_opt['color']['color'] . ';' : '';
                        $style .= !empty($more_opt['color']['bg']) ? '--this-bg:' . $more_opt['color']['bg'] . ';' : '';

                        $class = 'float-btn more-btn';
                        $hover = '';
                        $hover_style = '';
                        $tooltip_attr = $tooltip;
                        $tag = 'a';
                        if (!empty($more_opt['hover'])) {
                            $hover_style = '';
                            $tooltip_attr = '';
                            $tag = 'span';
                            $class .= ' hover-show';
                            if (!empty($more_opt['hover_width']) && $more_opt['hover_width'] != 200) {
                                $hover_style = ' style="width:' . $more_opt['hover_width'] . 'px;"';
                            }
                            $hover = '<div' . $hover_style . ' class="hover-show-con dropdown-menu">' . $more_opt['hover'] . '</div>';
                        }

                        $icon = $more_opt['icon'] ? '<i class="' . $more_opt['icon'] . '"></i>' : '<i class="fa fa-heart"></i>';
                        $href = !empty($more_opt['link']['url']) ? $more_opt['link']['url'] : 'javascript:;';
                        $target = (!empty($more_opt['link']['target']) && !empty($more_opt['link']['url'])) ? ' target="' . $more_opt['link']['target'] . '"' : '';
                        $title = $more_opt['desc'] ? $tooltip_attr . ' data-placement="left" title="' . $more_opt['desc'] . '"' : '';
                        $style = $style ? ' style="' . $style . '"' : '';

                        if ($href == 'javascript:;') $class .= ' nowave';

                        $btn .=  '<' . $tag . $style . ' class="' . $class . '"' . $target . $title . ' href="' . $href . '">' . $icon . $hover . '</' . $tag . '>';
                    }
                }

                break;
        }
    }

    $btn = apply_filters('zib_float_right', $btn);
    $class = _pz('float_btn_style', 'round') . ' position-' . _pz('float_btn_position', 'bottom');
    $filter_pz = (array)_pz('float_btn_filter_css', array('m_s'));
    $class .=  (($is_mobile && in_array('m_s', $filter_pz)) || (!$is_mobile && in_array('pc_s', $filter_pz))) ? ' filter' : '';

    echo '<div class="float-right ' . $class . '">' . $btn . '</div>';
}
add_action('wp_footer', 'zib_float_right');


//-----底部页脚内容------
if (_pz('fcode_template') == 'template_1') {
    add_action('zib_footer_conter', 'zib_footer_con');
}
function zib_footer_con()
{

    $show_xs_1 = _pz('footer_t1_m_s');
    $show_xs_3 = _pz('footer_mini_img_m_s', true);
    $html = '';
    $box = '<li' . (!$show_xs_1 ? ' class="hidden-xs"' : '') . ' style="max-width: 300px;">' . zib_footer_con_1() . '</li>';
    $box .= '<li style="max-width: 550px;">' . zib_footer_con_2() . '</li>';
    $box .= '<li' . (!$show_xs_3 ? ' class="hidden-xs"' : '') . '>' . zib_footer_con_3() . '</li>';

    $c_code = _pz('fcode_customize_code');
    $c_code = $c_code ? '<p class="footer-conter">' . $c_code . '</p>' : '';
    $html = '<ul class="list-inline">' . $box . '</ul>';
    $html .= $c_code;
    echo $html;
}

function zib_footer_con_1()
{
    $html = '';

    if (_pz('footer_t1_img')) {
        $html .= '<p><a class="footer-logo" href="' . esc_url(home_url()) . '" title="' . _pz('hometitle') . '">
                    ' . zib_get_adaptive_theme_img(_pz('footer_t1_img'), _pz('footer_t1_img_dark'), _pz('hometitle'), 'class="lazyload" height="40"', zib_is_lazy('lazy_other', true)) . '
                </a></p>';
    }

    if (_pz('footer_t1_t')) {
        $html .= '<p class="title-h-left">' . _pz('footer_t1_t') . '</p>';
    }

    if (_pz('fcode_t1_code')) {
        $html .= '<div class="footer-muted em09">' . _pz('fcode_t1_code') . '</div>';
    }
    return $html;
}

function zib_footer_con_2()
{
    $html = '';

    if (_pz('fcode_t2_code_1')) {
        $html .= '<p class="fcode-links">' . _pz('fcode_t2_code_1') . '</p>';
    }

    if (_pz('fcode_t2_code_2')) {
        $html .= '<div class="footer-muted em09">' . _pz('fcode_t2_code_2') . '</div>';
    }
    $s_src = ZIB_TEMPLATE_DIRECTORY_URI . '/img/thumbnail-sm.svg';
    $m_show = _pz('footer_contact_m_s', true) ? '' : ' hidden-xs';
    $html .= '<div class="footer-contact mt10' . $m_show . '">';
    if ((!wp_is_mobile() || _pz('footer_contact_m_s', true)) && _pz('footer_contact_wechat_img')) {
        $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="lazyload" src="' . $s_src . '" data-' : '';

        $s_img = '';
        $s_img .= '<div class="hover-show-con footer-wechat-img">';
        $s_img .= '<img style="box-shadow: 0 5px 10px rgba(0,0,0,.2); border-radius:4px;" height="100" ' . $lazy_attr . 'src="' . _pz('footer_contact_wechat_img') . '" alt="扫一扫加微信' . _get_delimiter() . get_bloginfo('name') . '">';
        $s_img .= '</div>';

        $html .= '<a class="toggle-radius hover-show nowave" href="javascript:;">' . zib_get_svg('d-wechat') . $s_img . '</a>';
    }
    if (_pz('footer_contact_qq')) {
        $html .= '<a class="toggle-radius" data-toggle="tooltip" target="_blank" title="QQ联系" href="http://wpa.qq.com/msgrd?v=3&uin=' . _pz('footer_contact_qq') . '&site=qq&menu=yes">' . zib_get_svg('d-qq', '-50 0 1100 1100') . '</a>';
    }
    if (_pz('footer_contact_weibo')) {
        $html .= '<a class="toggle-radius" data-toggle="tooltip" title="微博" href="' . _pz('footer_contact_weibo') . '">' . zib_get_svg('d-weibo') . '</a>';
    }
    if (_pz('footer_contact_email')) {
        $html .= '<a class="toggle-radius" data-toggle="tooltip" title="发邮件" href="mailto:' . _pz('footer_contact_email') . '">' . zib_get_svg('d-email', '-20 80 1024 1024') . '</a>';
    }
    $html .= '</div>';
    return $html;
}


function zib_footer_con_3()
{
    $html = '';
    $imgs = (array)_pz('footer_mini_img');
    if (!$imgs) return;
    $s_src = ZIB_TEMPLATE_DIRECTORY_URI . '/img/thumbnail-sm.svg';
    $lazy_attr = zib_is_lazy('lazy_other', true) ? 'class="lazyload" src="' . $s_src . '" data-' : '';

    foreach ($imgs as $img) {
        if (!empty($img['image'])) {
            $text = !empty($img['text']) ? $img['text'] : '';
            $html .= '<div class="footer-miniimg"' . ($text ? ' data-toggle="tooltip" title="' . $text  . '"' : '') . '>
            <p>
            <img ' . $lazy_attr . 'src="' . $img['image'] . '" alt="' . $text . _get_delimiter() . get_bloginfo('name') . '">
            </p>
            <span class="opacity8 em09">' . $text . '</span>
        </div>';
        }
    }
    return $html;
}

/**挂钩_GET参数打开tab */
function zib_url_show_tab()
{

    if (!empty($_GET['show_tab'])) {
        echo '<script type="text/javascript">';
        echo 'window._win.show_tab = "' . $_GET['show_tab'] . '";';
        if (!empty($_GET['show_tab2'])) {
            echo 'window._win.show_tab2 = "' . $_GET['show_tab2'] . '";';
        }
        if (!empty($_GET['show_tab3'])) {
            echo 'window._win.show_tab3 = "' . $_GET['show_tab3'] . '";';
        }
        echo '</script>';
    }
}
add_action('wp_footer', 'zib_url_show_tab', 99);

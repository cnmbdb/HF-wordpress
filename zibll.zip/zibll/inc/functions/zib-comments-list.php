<?php
/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2020-09-29 13:18:37
 * @LastEditTime: 2021-08-31 17:43:06
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */
function zib_comments_list($comment, $args, $depth)
{
	$GLOBALS['comment'] = $comment;
	global $commentcount, $wpdb, $post;
	//echo esc_attr(json_encode($args));
	zib_get_comments_list($comment, $depth);
}

function zib_get_comments_list($comment, $depth = 0, $echo = true)
{

	if (!$comment) return false;
	$user_id = $comment->user_id;
	$comment_id = $comment->comment_ID;
	$is_mobile = wp_is_mobile();

	$c_like = zib_get_comment_like('action action-comment-like muted-2-color', $comment_id);
	$vip_icon = '';
	if ($user_id) {
		$vip_icon = zibpay_get_vip_icon(zib_get_user_vip_level($user_id), "");
		$vip_icon = $vip_icon ? '<div class="avatar-icontag">' . $vip_icon . '</div>' : '';
	}

	$author_url = '';
	$author_avatar = '<div class="comt-avatar mr10 relative">' . zib_get_data_avatar($user_id) . $vip_icon . '</div>';
	$author_link  = '<b class="mr6">' . get_comment_author($comment->comment_ID) . '</b>';
	if ($user_id) {
		$author_url = zib_get_user_home_url($user_id);
		$author_avatar = '<a href="' . $author_url  . '">' . $author_avatar . '</a>';
		$author_link = '<a href="' . $author_url . '">' . $author_link . '</a>';
		if ($user_id ==  get_the_author_meta('ID') && _pz('comment_author_tag', true)) {
			$author_link  .= '<span class="badg c-red hollow badg-sm">作者</span>';
		}
	}

	$badg_approve = '';
	if ($comment->comment_approved == '0') {
		$badg_approve = '<span class="badg c-red badg-sm">待审核</span>';
	}
	$author_link .= '<span class="badge-approve ml6">' . $badg_approve . '</span>';
	$author_link = '<div class="author-title">' . $author_link . '</div>';
	$author_box = '<div class="author-box flex ac">' . $author_avatar . $author_link . '</div>';

	$comment_parent_html = '';
	if ($comment->comment_parent > 0) {
		$comment_parent_html = '<span>@<a rel="nofollow" class="url" href="javascript:(scrollTo(\'#comment-' . $comment->comment_parent . '\',-70));">' . get_comment_author($comment->comment_parent) . '</a></span>';
	}

	$replyText_html = '';
	$max_depth = get_option('thread_comments_depth');
	if ($comment->comment_approved != '0' && $depth && !zib_is_close_sign()) {
		$replyText = get_comment_reply_link(array('add_below' => 'div-comment', 'reply_text' => '回复', 'login_text' => '回复', 'depth' => $depth, 'max_depth' => $max_depth), $comment->comment_ID);
		if (strstr($replyText, 'reply-login')) {
			$replyText =  preg_replace('# class="[\s\S]*?" href="[\s\S]*?"#', ' class="signin-loader" href="javascript:;"', $replyText);
		} else {
			$replyText =  preg_replace('# aria-label=#', $is_mobile ? ' title=' : ' data-toggle="tooltip" title=', $replyText);
		}
		$replyText_html = '<span class="reply-link">' . $replyText . '</span>';
	}

	$is_super_admin = is_super_admin();
	$edit_but_html = '';
	if ((_pz('user_edit_comment', 'true') && $user_id && $user_id == get_current_user_id()) || $is_super_admin) {
		$edit_but = '<a class="comment-edit-link" data-commentid="' . $comment->comment_ID . '" data-postid="' . $comment->comment_post_ID . '" href="javascript:;"><i class="fa fa-edit mr10 fa-fw" aria-hidden="true"></i>编辑</a>';
		$trash_but = '<a class="comment-trash-link c-red" data-commentid="' . $comment->comment_ID . '" data-postid="' . $comment->comment_post_ID . '" href="javascript:;"><i class="fa fa-trash-o mr10 fa-fw" aria-hidden="true"></i>删除</a>';

		$list = '';
		if ($is_super_admin) {
			$text = $comment->comment_approved == '0' ? '批准' : '驳回';
			$approved_class = $comment->comment_approved == '0' ? 'approve' : 'unapprove';

			$list .= '<li><a class="comment-approve-link ' . $approved_class . '" data-commentid="' . $comment->comment_ID . '" data-postid="' . $comment->comment_post_ID . '" href="javascript:;">' . zib_get_svg('approve', null, 'mr10 icon fa-fw') . '<text>' . $text . '</text></a></li>';
		}
		$list .= '<li>' . $edit_but . '</li>';
		$list .= '<li>' . $trash_but . '</li>';

		$icon_a = '<a href="javascript:;" class="muted-color padding-6" data-toggle="dropdown">';
		$icon_a .= zib_get_svg('menu_2');
		$icon_a .= '</a>';

		$edit_but_html = '<span class="dropdown padding-6">' . $icon_a . '<ul class="dropdown-menu">' . $list . '</ul></span>';
	}


	$con = zib_comment_filters(get_comment_text($comment_id));

	$html = '';

	$html .= '<li ' . comment_class('', $comment_id, null, false) . ' id="comment-' . $comment_id . '">';
	$html .=  '<ul class="list-inline">';

	$html .=  '<li class="comt-main" id="div-comment-' . $comment_id . '">';

	$html .= '<div class="comment-header mb10 flex jsb">' . $author_box . $c_like . '</div>';

	$html .= '<div class="comment-footer">';
	$html .= '<div class="mb10 comment-content">' . $con . '</div>';
	$html .= '<div class="comt-meta muted-2-color">';

	$html .= '<span class="comt-author" title="' . $comment->comment_date . '">';
	$html .= zib_get_time_ago($comment->comment_date);
	$html .= '</span>';
	$html .= $comment_parent_html;
	$html .= $replyText_html;
	$html .= $edit_but_html;
	$html .= '</div>';
	$html .= '</div>';

	$html .= '</li>';
	$html .= '</ul>';

	if ($echo) {
		echo $html;
	} else {
		return $html;
	}
}

function zib_comments_author_list($comment, $args = '')
{
	if (!$comment) return false;
	$cont =  zib_comment_filters(get_comment_text($comment->comment_ID), 'noimg');

	$_link = get_comment_link($comment->comment_ID);
	$post_title = get_the_title($comment->comment_post_ID);
	$post_tlink = get_the_permalink($comment->comment_post_ID);

	$time = $comment->comment_date;
	$approved = '';
	$parent = '';
	$post = '<a class="muted-color" href="' . $post_tlink . '">' . $post_title . '</a>';

	$cont = '<a class="muted-color text-ellipsis-5" href="' . $_link . '">' . $cont . '</a>';
	if ($comment->comment_parent > 0) {
		$parent = '<span class="mr10" >@' . get_comment_author($comment->comment_parent) . '</span>';
	}

	if ($comment->comment_approved == '0') {
		$approved = '<span class="badg c-red badg-sm mr6">待审核</span>';
	}

	$time = zib_get_time_ago($comment->comment_date);

	echo '<div class="author-set-left muted-2-color" title="' . $comment->comment_date . '">';
	echo $time;
	echo '</div>';

	echo '<div class="author-set-right">';
	echo '<div class="mb10 comment-content">';
	echo $approved . $cont;

	echo '</div>';
	echo '<span class="muted-2-color em09">';
	echo $parent . '评论于：' . $post;

	echo '</span>';

	echo '</div>';
}


function zib_widget_comments($limit, $outpost, $outer)
{
	global $wpdb;
	$args = array(
		'orderby' => 'comment_date',
		'number' => $limit,
		'status' => 'approve',
		'author__not_in' =>  preg_split("/,|，|\s|\n/", $outer),
		'post__not_in' =>  preg_split("/,|，|\s|\n/", $outpost),
	);

	$comments = get_comments($args);

	$output = '';
	foreach ($comments as $comment) {
		$cont =  zib_comment_filters(get_comment_text($comment->comment_ID), 'noimg');
		$_link = get_comment_link($comment->comment_ID);
		//$post_title = $comment->post_title;
		//$post_link = get_the_permalink($comment->ID);
		$time = zib_get_time_ago($comment->comment_date);
		$user_name = get_comment_author($comment->comment_ID);
		$user_id = $comment->user_id;
		$c_like = zib_get_comment_like('action action-comment-like pull-right muted-2-color', $comment->comment_ID);
		$vip_icon = '';

		if ($user_id) {
			$user_name = '<a href="' . get_author_posts_url($user_id) . '">' . $user_name . '</a>';
			$vip_icon = zibpay_get_vip_icon(zib_get_user_vip_level($user_id), "");
			$vip_icon = $vip_icon ? '<div class="avatar-icontag">' . $vip_icon . '</div>' : '';
		}
		$avatar = '<div class="avatar-img">' . zib_get_data_avatar($user_id, '22') . $vip_icon . '</div>';

		echo '<div class="posts-mini">';
		echo $avatar;
		echo '<div class="posts-mini-con em09 ml10 flex xx jsb">';
		echo '<p class="flex jsb">';
		echo '<span>';
		echo $user_name;
		echo '<span class="icon-spot muted-3-color" title="' . $comment->comment_date . '">' . $time . '</span>';
		echo '</span>';

		echo '<span>' . $c_like . '</span>';
		echo '</p>';

		echo '<a class="muted-color text-ellipsis-5" href="' . $_link . '">' . $cont . '</a>';
		echo '</div>';
		echo '</div>';
	}
};

function zib_comment_filters($cont, $type = '', $lazy = true)
{
	$cont = convert_smilies($cont);

	$cont =  preg_replace('/\[img=(.*?)\]/', '<img class="box-img lazyload" src="$1" alt="评论图片' . _get_delimiter() . get_bloginfo('name') . '">', $cont);

	if ($type == 'noimg') {
		$cont =  preg_replace('/\<img(.*?)\>/', '[图片]', $cont);
		$cont =  preg_replace('/\[code]([\s\S]*)\[\/code]/', '[代码]', $cont);
	} else {
		$cont =  str_replace('[code]', '<pre><code>', $cont);
		$cont =  str_replace('[/code]', '</code></pre>', $cont);
	}

	$cont =  preg_replace('/\[g=(.*?)\]/', '<img class="smilie-icon" src="' . ZIB_TEMPLATE_DIRECTORY_URI . '/img/smilies/$1.gif" alt="表情[$1]' . _get_delimiter() . get_bloginfo('name') . '">', $cont);
	if (zib_is_lazy('lazy_comment') && $lazy) {
		$cont =  str_replace(' src=', ' src="' . zib_get_lazy_thumb() . '" data-src=', $cont);
	}
	//

	$cont = wp_kses_post($cont);
	return $cont;
}

add_filter('comments_template_query_args', 'zib_comments_template_query_args');
function zib_comments_template_query_args($comment_args)
{
	$comment_args['order'] = 'DESC';

	if (is_super_admin()) $comment_args['status'] = array('hold', 'approve');

	if (isset($_GET['corderby'])) {
		if (in_array($_GET['corderby'], array('comment_like'))) {
			$comment_args['orderby'] = 'meta_value_num';
			$comment_args['meta_key'] = $_GET['corderby'];
		} else {
			$comment_args['orderby'] = $_GET['corderby'];
		}
	}

	if (!empty($_GET['only_author'])) {
		$comment_args['author__in'] = [$_GET['only_author']];
		$comment_args['hierarchical'] = false;
	}
	return $comment_args;
}


//获取评论翻页按钮
function zib_paginate_comments_links()
{
	if (!is_singular()) {
		return;
	}

	if (_pz('comment_paginate_type') == 'ajax_lists') {
		//ias自动加载
		$paged = get_query_var('cpage');
		$paged = $paged ? $paged : 1;

		$nextpage = (int) $paged + 1;
		global $wp_query;
		$max_page = $wp_query->max_num_comment_pages;
		if (empty($max_page)) {
			$max_page = get_comment_pages_count();
		}
		if ($nextpage > $max_page) {
			return;
		}
		$next = get_comments_pagenum_link($nextpage, $max_page);
		if (!$next) return;

		$ajax_trigger = _pz("ajax_trigger", '加载更多');
		if (isset($_GET['corderby'])) {
			$next = add_query_arg('corderby', $_GET['corderby'], $next);
		}
		if (!empty($_GET['only_author'])) {
			$next = add_query_arg('only_author', $_GET['only_author'], $next);
		}

		$ias_max = _pz('comment_paging_ajax_ias_max', 3);
		$ias_attr = (_pz('comment_paging_ajax_ias_s') && ($paged <= $ias_max || !$ias_max)) ? ' class="theme-pagination lazyload ias-pagenav pagenav" lazyload-action="ias"' : '  class="theme-pagination ias-pagenav pagenav"';

		$pag_html = '<div' . $ias_attr . '><div class="order-ajax-next"><a href="' . esc_url($next) . '" class="page-numbers" no-replace="true">' . $ajax_trigger . '</a></div></div>';
	} else {
		$args = array(
			'type' => 'array',
			'prev_text' => '<i class="fa fa-angle-left em12"></i><span class="hide-sm ml6">上一页</span>',
			'next_text' => '<span class="hide-sm mr6">下一页</span><i class="fa fa-angle-right em12"></i>',
		);
		$array = paginate_comments_links($args);
		if (!$array) return;
		$pag_html = '<div class="pagenav">';
		$pag_html .= implode("", $array);
		$pag_html .= '</div>';
	}

	echo $pag_html;
}

//新建评论时候，为评论添加参数
do_action('wp_insert_comment', function ($id) {
	add_comment_meta($id, 'comment_like', 0);
});

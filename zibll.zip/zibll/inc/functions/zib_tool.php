<?php

/*
 * @Author        : Qinver
 * @Url           : 7s.cx
 * @Date          : 2021-08-05 17:40:41
 * @LastEditTime: 2021-08-29 12:50:56
 * @Email         : 2621629456@qq.com
 * @Project       : 七思网
 * @Description   : 一款极其优雅的Wordpress主题|工具函数
 * @Read me       : 感谢您使用七思网，主题源码有详细的注释，支持二次开发。欢迎各位朋友与我相互交流。
 * @Remind        : 使用盗版主题会存在各种未知风险。支持正版，从我做起！
 */


/**判断是否在微信APP内 */
function zib_is_wechat_app()
{
    $useragent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    return strripos($useragent, 'micromessenger');
}

//删除内容或者数组的两端空格
function zib_trim($Input)
{
    if (!is_array($Input)) {
        return trim($Input);
    }
    return array_map('zib_trim', $Input);
}

//判断是否是蜘蛛爬虫
$zib_is_crawler = 'is_null';
function zib_is_crawler()
{
    global $zib_is_crawler;
    //载入全局变量，提高执行效率
    if ($zib_is_crawler != 'is_null') return $zib_is_crawler;

    $bots = array(
        'Baidu' => 'baiduspider',
        'Google Bot' => 'google',
        '360spider' => '360spider',
        'Sogou' => 'spider',
        'soso.com' => 'sosospider',
        'MSN' => 'msnbot',
        'Alex' => 'ia_archiver',
        'Lycos' => 'lycos',
        'Ask Jeeves' => 'jeeves',
        'Altavista' => 'scooter',
        'AllTheWeb' => 'fast-webcrawler',
        'Inktomi' => 'slurp@inktomi',
        'Turnitin.com' => 'turnitinbot',
        'Technorati' => 'technorati',
        'Yahoo' => 'yahoo',
        'Findexa' => 'findexa',
        'NextLinks' => 'findlinks',
        'Gais' => 'gaisbo',
        'WiseNut' => 'zyborg',
        'WhoisSource' => 'surveybot',
        'Bloglines' => 'bloglines',
        'BlogSearch' => 'blogsearch',
        'PubSub' => 'pubsub',
        'Syndic8' => 'syndic8',
        'RadioUserland' => 'userland',
        'Gigabot' => 'gigabot',
        'Become.com' => 'become.com',
        'Yandex' => 'yandex'
    );
    $useragent = isset($_SERVER['HTTP_USER_AGENT']) ? addslashes(strtolower($_SERVER['HTTP_USER_AGENT'])) : '';
    $zib_is_crawler = false;
    if ($useragent) {
        foreach ($bots as $name => $lookfor) {
            if (!empty($useragent) && (false !== stripos($useragent, $lookfor))) {
                $zib_is_crawler = $name;
            }
        }
    }

    return $zib_is_crawler;
}

/**后台生成二维码图片 */
function zib_get_qrcode_base64($url)
{
    //引入phpqrcode类库
    require_once get_theme_file_path('/inc/class/qrcode.class.php');
    $errorCorrectionLevel = 'L'; //容错级别
    $matrixPointSize      = 6; //生成图片大小
    ob_start();
    QRcode::png($url, false, $errorCorrectionLevel, $matrixPointSize, 2);
    $data = ob_get_contents();
    ob_end_clean();

    $imageString = base64_encode($data);
    header("content-type:application/json; charset=utf-8");
    return 'data:image/jpeg;base64,' . $imageString;
}

//判断是否启用了图片懒加载
function zib_is_lazy($key, $default = false)
{
    if (zib_is_crawler()) return false;
    return _pz($key, $default);
}
